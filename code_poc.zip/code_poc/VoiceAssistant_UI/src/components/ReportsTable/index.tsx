/* eslint-disable jsx-a11y/anchor-is-valid */
import * as React from "react";
import { Modal } from "react-bootstrap";
import { MediaService } from "../../services/MediaService";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import "./index.css";

interface State {
  showModal: boolean;
  showImageInPopup: string;
  isStartAudio1: any;
  isStartAudio2: any;
}

interface Props {
  reports: any;
}

export class ReportsTable extends React.Component<Props, State> {
  mediaService: MediaService;
  audioElement: any;
  constructor(prop: Props) {
    super(prop);

    this.mediaService = new MediaService(this);
    this.playAudio = this.playAudio.bind(this);
  }

  state: State = {
    showModal: false,
    showImageInPopup: "",
    isStartAudio1: false,
    isStartAudio2: false
  };

  handleClose = () => {
    this.setState({ showModal: false });
  };

  handleShow = imageURL => {
    this.setState({ showImageInPopup: imageURL });
    this.setState({ showModal: true });
  };

  playAudio = (audioUrl, iconNumber) => {
    this.audioElement = new Audio(audioUrl);
    this.audioElement.play();
    (iconNumber === 1) ? this.setState({isStartAudio1: true}) : this.setState({isStartAudio2: true})
    
    this.audioElement.addEventListener('loadeddata', () => {
    setTimeout((_this) => {
      (iconNumber === 1) ? this.setState({isStartAudio1: false}) : this.setState({isStartAudio2: false}) 
    }, this.audioElement.duration * 1000);
    })
  };
  stopAudio = (audioUrl, iconNumber) => {
    this.audioElement.pause();
    this.audioElement.currentTime = 0;
    (iconNumber === 1) ? this.setState({isStartAudio1: false}) : this.setState({isStartAudio2: false})
  }

  render() {
    const { reports } = this.props;
    return (
      <>
        <div className="col-md-6 view-details">
          <div className="report-table">
            {reports ? (
              <>
                <div className="row">
                  <div className="col test-result">
                    <label>Test Result</label>
                  </div>
                  
                </div>
                <div className="row">
                  <div className="col-md-4 heading-case-name">
                    <label>Test Case Name</label>
                  </div>
                  <div className="col-md-8 test-case-result-name">
                    <label>{reports.testCaseName}</label>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-4 heading-case-name">
                    <label>Command</label>
                  </div>
                  <div className="col-md-8 test-case-result-name">
                    <label>{reports.inputText}</label>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12 test-result">
                    <p
                      className=" full-width"
                    >
                      Test Result
                    </p>
                  </div>
                </div>
                <div className="table-div">
                  <div className="row row-table">
                    <div className="col-md-2  heading-case-name">
                      <label>Type</label>
                    </div>
                    <div className="col-md-3  heading-case-name tex">
                      <label>Actual</label>
                    </div>
                    <div className="col-md-4  heading-case-name">
                      <label>Expected</label>
                    </div>
                    <div className="col-md-1 heading-case-name tex">
                      <label>Score</label>
                    </div>
                    <div className="col-md-2  heading-case-name tex">
                      <label>Result</label>
                    </div>
                  </div>

                  <div className="row row-table">
                    <div className="form-group col-md-2  test-case-result-name">
                      <label> Audio</label>
                    </div>
                    <div className="col-md-3  test-case-result-name actual">
                      <label>
                        {reports.recordedAudioTxt
                          ? reports.recordedAudioTxt
                          : "record is empty"}
                      </label>
                      {
                        this.state.isStartAudio2 ?
                          <a
                          className="link"
                          onClick={this.stopAudio.bind(this,reports.recordedAudioURL, 2)}
                        >
                          <p>
                            
                            <FontAwesomeIcon icon="stop-circle" /> Actual Audio
                          </p>
                          </a>
                        : 
                          <a
                          className="link"
                          onClick={this.playAudio.bind(this,reports.recordedAudioURL, 2)}
                        >
                          <p>
                            
                            <FontAwesomeIcon icon="volume-up" /> Actual Audio
                          </p>
                          </a>
                      }
                    </div>
                    <div className="col-md-4  test-case-result-name expected">
                      <label>
                        {reports.expectedOutputTxt ? (
                          <ol className="list-group">
                            {reports.expectedOutputTxt ? reports.expectedOutputTxt
                              .split("|")
                              .map((splitData: any, index) => (
                              <li key={index}>{splitData} (<b>{reports.actualResponse ? reports.actualResponse.split('|')[index] : "00"}</b>)</li>
                              )) : "record is empty"}
                          </ol>
                        ) : (
                          "record is empty"
                        )}
                      </label>
                      {
                        this.state.isStartAudio1 
                        ?
                          <a
                            className="link"
                            onClick={this.stopAudio.bind(
                              this,
                              reports.inputAudioURL, 1
                            )}
                          >
                            <p>
                              <FontAwesomeIcon icon="stop-circle" /> Expected Audio
                            </p>
                          </a>
                        :
                          <a
                            className="link"
                            onClick={this.playAudio.bind(
                              this,
                              reports.inputAudioURL, 1
                            )}
                          >
                            <p>
                              <FontAwesomeIcon icon="volume-up" /> Expected Audio
                            </p>
                          </a>
  }
                    </div>
                    <div className="col-md-1  test-case-result-name text-center">
                      <label>
                        {reports.audioScore ? reports.audioScore : "00"}
                      </label>
                    </div>
                    <div className="col-md-2  test-case-result-name">
                      <label
                        className={
                          reports.audioScore < 0.5 ? "alert-red" : "alert-green"
                        }
                      >
                        {reports.audioScore< 0.5?"FAIL":"PASS"}
                      </label>
                    </div>
                  </div>
                  <div className="row row-table">
                    <div className="col-md-2  test-case-result-name">
                      <label>Image</label>
                    </div>
                    <div className="col-md-3  test-case-result-name actual">
                      <label>
                        {reports.recordedImageTxt
                          ? reports.recordedImageTxt
                          : "record is empty"}
                      </label>
                      <a
                        className="link"
                        onClick={this.handleShow.bind(
                          this,
                          reports.recordedImageURL
                        )}
                      >
                        <p>
                          <FontAwesomeIcon icon="camera" /> Actual Image
                        </p>
                      </a>
                    </div>
                    <div className="col-md-4 test-case-result-name expected">
                      <label>
                        {reports.inputImageTxt
                          ? reports.inputImageTxt
                          : "record is empty"}
                      </label>
                      <a
                        className="link"
                        onClick={this.handleShow.bind(
                          this,
                          reports.inputImgURL
                        )}
                      >
                        <p>
                          <FontAwesomeIcon icon="camera" /> Expected Image
                        </p>
                      </a>
                    </div>
                    <div className="col-md-1  test-case-result-name text-center">
                      <label>
                        {reports.imageScore ? reports.imageScore : "00"}
                      </label>
                    </div>
                    <div className="col-md-2  test-case-result-name">
                      <label
                        className={
                          reports.imageScore < 0.5 ? "alert-red" : "alert-green"
                        }
                      >
                         {reports.imageScore < 0.5?"FAIL":"PASS"}
                      </label>
                    </div>
                  </div>
                  <Modal show={this.state.showModal} onHide={this.handleClose}>
                    <Modal.Header closeButton></Modal.Header>
                    <Modal.Body>
                      <img
                        src={this.state.showImageInPopup}
                        alt={reports.inputText}
                      ></img>
                    </Modal.Body>
                  </Modal>
                  <div className="row">
                    {reports.result === "PASS" ? (
                      <div className="col-md-12 text-right alert-green">
                        <p className="total-score">
                          Total Score = <b>{reports.score}</b>
                        </p>
                      </div>
                    ) : (
                      <div className="col-md-12 text-right alert-red">
                        <p className="total-score">
                          Total Score ={" "}
                          <b>{reports.score ? reports.score : "00"}</b>
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <h4 className="text-center">
                <div className="alert alert-danger" role="alert">
                  Test case name is not selected
                </div>
              </h4>
            )}
          </div>
        </div>
      </>
    );
  }
}
