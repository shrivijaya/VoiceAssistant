package com.hcl.va.bean;

import java.time.LocalDateTime;

public class TestData {

	private String inputText;

	private String expectedOutput;

	private String imgToText;

	private Integer id;

	private String imgUrl;

	private String inputAudioURL;

	private String language;

	private String testCaseName;

	private Boolean isChecked;

	private LocalDateTime createdDate;

	private String base64Image;
	
    private Integer parentId;
	
	private Boolean isContextual;
	
	private Integer childId;
	
    private TestData childData;

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Boolean getIsContextual() {
		return isContextual;
	}

	public void setIsContextual(Boolean isContextual) {
		this.isContextual = isContextual;
	}

	public Integer getChildId() {
		return childId;
	}

	public void setChildId(Integer childId) {
		this.childId = childId;
	}

	public TestData getChildData() {
		return childData;
	}

	public void setChildData(TestData childData) {
		this.childData = childData;
	}

	public String getBase64Image() {
		return base64Image;
	}

	public void setBase64Image(String base64Image) {
		this.base64Image = base64Image;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getTestCaseName() {
		return testCaseName;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getInputAudioURL() {
		return inputAudioURL;
	}

	public void setInputAudioURL(String inputAudioURL) {
		this.inputAudioURL = inputAudioURL;
	}

	public String getInputText() {
		return inputText;
	}

	public void setInputText(String inputText) {
		this.inputText = inputText;
	}

	public String getExpectedOutput() {
		return expectedOutput;
	}

	public void setExpectedOutput(String expectedOutput) {
		this.expectedOutput = expectedOutput;
	}

	public String getImgToText() {
		return imgToText;
	}

	public void setImgToText(String imgToText) {
		this.imgToText = imgToText;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Boolean isChecked) {
		this.isChecked = isChecked;
	}
}
