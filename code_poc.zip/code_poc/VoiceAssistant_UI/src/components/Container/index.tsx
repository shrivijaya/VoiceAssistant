import React from 'react';
import { Navigation, Header, Content, Footer } from '../../components';
import './index.css'
export class Container extends React.Component {
   render() {
      return (
         <>
            <Header> </Header>
            <Content></Content>
            <Footer></Footer>
         </>
      );
   }
}
