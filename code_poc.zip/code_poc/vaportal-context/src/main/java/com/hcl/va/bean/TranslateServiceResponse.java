package com.hcl.va.bean;

public class TranslateServiceResponse {
	private String translatedText;
	private String translatedAudioFilePath;
	
	public String getTranslatedText() {
		return translatedText;
	}
	public void setTranslatedText(String translatedText) {
		this.translatedText = translatedText;
	}
	public String getTranslatedAudioFilePath() {
		return translatedAudioFilePath;
	}
	public void setTranslatedAudioFilePath(String translatedAudioFilePath) {
		this.translatedAudioFilePath = translatedAudioFilePath;
	}
}
