package com.hcl.va.service;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.hcl.va.bean.AppResponse;
import com.hcl.va.bean.Message;
import com.hcl.va.bean.TestExecute;
import com.hcl.va.bean.TestRunReportBean;
import com.hcl.va.bean.TestSuitRunReportBean;
import com.hcl.va.model.TestCase;
import com.hcl.va.model.TestRunReport;
import com.hcl.va.model.TestSuitRunReport;
import com.hcl.va.model.TestSuite;
import com.hcl.va.repository.TestCaseRepository;
import com.hcl.va.repository.TestRunReportRepository;
import com.hcl.va.repository.TestSuitRunReportRepository;
import com.hcl.va.transformer.TestRunReportTransformer;
import com.hcl.va.transformer.TestSuitRunReportTransformer;
import com.hcl.va.util.FileUtils;

@Service
public class DataProcessingService {

	static final Logger log = LoggerFactory.getLogger(DataProcessingService.class);

	@Autowired
	private FileUploadService fileUploadService;

	@Autowired
	private TestCaseRepository testCaseRepository;

	@Autowired
	private TestRunReportRepository testRunReportRepository;

	@Autowired
	private PythonApiService pythonApiService;
	
	@Autowired
	private TestRunReportTransformer testRunReportTransformer;
	
	@Autowired
	private TestSuitRunReportRepository testSuitRunReportRepository;
	
	@Autowired
	private TestSuitRunReportTransformer testSuitRunReportTransformer;

	@Value("${imageToText.api.url}")
	private String imgToTextApiURL;

	@Value("${audioToText.api.url}")
	private String audioToTextApiURL;

	@Value("${textToAudio.api.url}")
	private String txtToAudioApiURL;

	@Value("${compareText.api.url}")
	private String compareTextApiURL;

	@Value("${compareText.api.url}")
	private String ffmpegPath;

	static String datePattern = "ddMMYYHHmmss";
	private static final  String EMPTY_STRING="";
	private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern(datePattern);
	
	private static final FileUtils FILE_UTIL = FileUtils.INSTANCE;

	@Transactional(readOnly = true)
	public List<TestRunReportBean> getTestSuiteReport(Integer testSuiteId, Integer runId) {
		List<TestRunReportBean> runReportBeans = new ArrayList<>();
		if(null == runId || runId.intValue()<=0) {
			List<TestSuitRunReport> testSuitRunReports = testSuitRunReportRepository
					.findByTestSuite_IdOrderByCreatedOnDesc(testSuiteId);
			runId = !CollectionUtils.isEmpty(testSuitRunReports)?testSuitRunReports.get(0).getId():0;
		}
		if (null != runId && runId.intValue() > 0) {
			List<TestRunReport> testRunReports = testRunReportRepository
					.findByTestSuitRunReport_Id(runId);
			Optional.ofNullable(testRunReports).ifPresent(testRunReportsList -> {
				runReportBeans.addAll(testRunReportsList.stream().map(testRunReportTransformer::transformBack)
						.collect(Collectors.toList()));
			});
		}
		return runReportBeans;
	}
	
	@Transactional(readOnly = true)
	public List<TestSuitRunReportBean> getTestSuiteRunReport(Integer testSuiteId) {
		List<TestSuitRunReportBean> runReportBeans = Collections.emptyList();
		List<TestSuitRunReport> testSuitRunReports = testSuitRunReportRepository
				.findByTestSuite_IdOrderByCreatedOnDesc(testSuiteId);
		if (!CollectionUtils.isEmpty(testSuitRunReports)) {
			runReportBeans = testSuitRunReports.stream().map(testSuitRunReportTransformer::transformBack)
					.collect(Collectors.toList());
		}
		return runReportBeans;
	}

	public AppResponse executeTestCases(List<TestExecute> testExecuteList) throws Exception {

		String parentResult = null;
		TestRunReportBean reportBean = new TestRunReportBean();
		for (int i = 0; i < testExecuteList.size(); i++) {
			TestExecute testExecute = testExecuteList.get(i);
			String testDataId = testExecute.getTestDataId();

			Optional<TestCase> optional = testCaseRepository.findById(Integer.parseInt(testExecute.getTestDataId()));
			TestCase testData = optional.get();
			log.info("test data id" + testDataId + " suite id " + testExecute.getSuiteId());
			if (reportBean == null) {
				reportBean = new TestRunReportBean();
			}

			reportBean.setTestCaseId(Integer.parseInt(testDataId));
			reportBean.setSuiteId(Integer.parseInt(testExecute.getSuiteId()));

			if (testExecute.getAudioBase64() != null) {
				calculateAudioScore(testData, testExecute.getAudioBase64(), reportBean);
			}
			if (testExecute.getImageBase64() != null) {
				calculateImageScore(testData, testExecute.getImageBase64(), reportBean);
			}
			if (reportBean.getAudioScore() != null && reportBean.getImageScore() != null) {
				reportBean.setScore((reportBean.getAudioScore() + reportBean.getImageScore()) / 2);
			} else {
				reportBean.setScore(
						reportBean.getAudioScore() == null ? reportBean.getImageScore() : reportBean.getAudioScore());
			}

			if (reportBean.getScore() == null) {
				reportBean.setResult("FAIL");
			} else {
				reportBean.setResult(reportBean.getScore() >= 0.5 ? "PASS" : "FAIL");
			}
			reportBean.setExpectedOutputTxt(testData.getExpectedOutputText());
			reportBean.setInputText(testData.getInputText());
			reportBean.setTestCaseName(testData.getTestCaseName());
			reportBean.setCreatedDate(LocalDateTime.now());
			reportBean.setInputAudioURL(testData.getInputAudioUrl());
			reportBean.setInputImgURL(testData.getImgUrl());
			reportBean.setInputImageTxt(testData.getImgExtractedText());
			TestRunReport report = testRunReportTransformer.transform(reportBean);
			report.setTestCase(testData);
			report.setCreatedOn(LocalDateTime.now());
			if (null != testExecute.getRunId() && testExecute.getRunId().intValue() > 0) {
				report.setTestSuitRunReport(testSuitRunReportRepository.getOne(testExecute.getRunId()));
			} else {
				createTestSuiteRunReport(report,
						StringUtils.isEmpty(testExecute.getSuiteId()) ? 0 : Integer.parseInt(testExecute.getSuiteId()));
			}
			testRunReportRepository.save(report);
			reportBean.setRunId(report.getTestSuitRunReport().getId());
			if (testData.getChildId() != null) {
				parentResult = reportBean.getResult();
			}
		}

		if (parentResult != null && reportBean.getResult() != null && reportBean.getResult().equalsIgnoreCase("PASS")) {
			if (parentResult.equalsIgnoreCase("FAIL")) {
				reportBean.setResult("FAIL");
			}
		}
		return buildResponse(reportBean);

	}
	
	private void createTestSuiteRunReport(TestRunReport testRunReport,Integer suiteId) {
		TestSuitRunReport newTestSuitRunReport = new TestSuitRunReport();
		newTestSuitRunReport.setCreatedOn(LocalDateTime.now());
		newTestSuitRunReport.setTestSuite(new TestSuite(suiteId));
		testSuitRunReportRepository.save(newTestSuitRunReport);
		testRunReport.setTestSuitRunReport(newTestSuitRunReport);
		
	}

	private void calculateAudioScore(TestCase testData, String audioBase64, TestRunReportBean report) throws Exception {
		try {
			report.setAudioScore(0.0);
			String outputTxt = null;
			File file = FILE_UTIL.saveImage(audioBase64, testData, false);
			String fileName = "AUD" + LocalDateTime.now().format(formatter) + ".wav";

			File wavFile = FILE_UTIL.callFfmpeg(file, fileName);

			String audioUrl = fileUploadService.uploadToAWS(wavFile);
			report.setRecordedAudioURL(audioUrl);
			MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();

			FileSystemResource value = new FileSystemResource(wavFile);
			map.add("file", value);
			map.add("lang", testData.getLanguage());
			ResponseEntity<String> response = pythonApiService.getResponseFrmPythonAPI(map, audioToTextApiURL);

			if (response.getBody() != null) {
				log.info("jobj=="+response.getBody());
				JsonObject jobj = new Gson().fromJson(response.getBody(), JsonObject.class);
				outputTxt = jobj.get("message")!=null? jobj.get("message").getAsString():EMPTY_STRING;
			}
			report.setRecordedAudioTxt(outputTxt);
			report.setActualResponse(null);

			if (!StringUtils.isEmpty(outputTxt) && !StringUtils.isEmpty(testData.getExpectedOutputText())) {
				map = new LinkedMultiValueMap<String, Object>();
				map.add("lang", testData.getLanguage());
				map.add("acttxt", outputTxt);
				map.add("exptxt", testData.getExpectedOutputText());

				response = pythonApiService.getResponseFrmPythonAPI(map, compareTextApiURL);

				if (response.getBody() != null) {
					Gson gson = new Gson();
					AppResponse appResponse = gson.fromJson(response.getBody(), AppResponse.class);
					if (appResponse.getMessage() != null) {
						handleScoreCalculation(report, appResponse);
					}
				}
			} else {
				log.info("campare api cannot call one arg is empty");
			}

		} catch (Exception e) {
			throw e;
		}
	}

	private void handleScoreCalculation(TestRunReportBean report, AppResponse appResponse) {
		List<Message> messageList = appResponse.getMessage();
		Double score = 0.0;
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < messageList.size(); i++) {
			Message message = messageList.get(i);
			builder.append(message.getScore());
			builder.append("|");

			if (Double.valueOf(message.getScore()) > score) {
				score = Double.valueOf(message.getScore());
			}
		}
		report.setActualResponse(builder.toString());

		report.setAudioScore(score);
	}

	private void calculateImageScore(TestCase testData, String imageBase64, TestRunReportBean report) throws Exception {
		try {
			report.setImageScore(0.0);
			String outputTxt = null;
			File file = FILE_UTIL.saveImage(imageBase64, testData, true);
			String audioUrl = fileUploadService.uploadToAWS(file);
			report.setRecordedImageURL(audioUrl);
			MultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();

			FileSystemResource value = new FileSystemResource(file);
			map.add("file", value);
			map.add("lang", testData.getLanguage());

			ResponseEntity<String> response = pythonApiService.getResponseFrmPythonAPI(map, imgToTextApiURL);

			if (response.getBody() != null) {
				JsonObject jobj = new Gson().fromJson(response.getBody(), JsonObject.class);
				outputTxt = jobj.get("message")!=null? jobj.get("message").getAsString():EMPTY_STRING;

			}
			report.setRecordedImageTxt(outputTxt);

			if (!StringUtils.isEmpty(outputTxt) && !StringUtils.isEmpty(testData.getImgExtractedText())) {
				map = new LinkedMultiValueMap<String, Object>();
				map.add("lang", testData.getLanguage());
				map.add("acttxt", outputTxt);
				map.add("exptxt", testData.getImgExtractedText());

				response = pythonApiService.getResponseFrmPythonAPI(map, compareTextApiURL);

				if (response.getBody() != null) {
					Gson gson = new Gson();
					AppResponse appResponse = gson.fromJson(response.getBody(), AppResponse.class);
					if (appResponse.getMessage().size() != 0 && appResponse.getMessage().get(0).getScore() != null) {
						report.setImageScore(Double.valueOf(appResponse.getMessage().get(0).getScore()));
					}
				}
			} else {
				log.info("campare api cannot call one arg is empty");
			}
		} catch (Exception e) {
			throw e;
		}
	}

	
	private AppResponse buildResponse(TestRunReportBean report) {
		AppResponse appResponse = new AppResponse("200", "Success");
		if (report != null) {
			appResponse.setScore(String.valueOf(report.getScore()));
			appResponse.setResult(report.getResult());
			appResponse.setRunId(report.getRunId());
		}

		return appResponse;
	}

	

}
