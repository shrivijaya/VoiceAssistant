
export class UtilityService {
    static getSecToMS(sec){return sec*1000;}
    static delay = sec => new Promise(resolve => setTimeout(resolve, UtilityService.getSecToMS(sec)));
}
