import { toast } from 'react-toastify';
toast.configure({
    position: toast.POSITION.TOP_RIGHT
});

export class NotifyService {
    notifyMessage = (message, statusCode) => {
        switch(statusCode) {
            case 200:
                toast.info(message);
                break;

            default: 
                toast.error(message);
        }
    }
}