export interface ReportList {
    id: number
    inputText: string
    expectedOutputTxt: string
    testCaseName: string
    result?: string
    recordedAudioURL?: string
    recordedImageURL?: string
    recordedImageTxt?: string
    recordedAudioTxt?: string
    score?: number
    audioScore?: number
    imageScore?: number
}