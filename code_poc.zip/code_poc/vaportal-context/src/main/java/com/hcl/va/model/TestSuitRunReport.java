package com.hcl.va.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the test_suit_run_report database table.
 * 
 */
@Entity
@Table(name="test_suit_run_report")
@NamedQuery(name="TestSuitRunReport.findAll", query="SELECT t FROM TestSuitRunReport t")
public class TestSuitRunReport implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name="CREATED_ON")
	private LocalDateTime createdOn;

	//bi-directional many-to-one association to RunReportDetail
	@OneToMany(mappedBy="testSuitRunReport")
	private List<TestRunReport> runReportDetails;

	//bi-directional many-to-one association to TestSuite
	@ManyToOne
	@JoinColumn(name="SUITE_ID")
	private TestSuite testSuite;

	public TestSuitRunReport() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public List<TestRunReport> getRunReportDetails() {
		return this.runReportDetails;
	}

	public void setRunReportDetails(List<TestRunReport> runReportDetails) {
		this.runReportDetails = runReportDetails;
	}

	public TestRunReport addRunReportDetail(TestRunReport runReportDetail) {
		getRunReportDetails().add(runReportDetail);
		runReportDetail.setTestSuitRunReport(this);

		return runReportDetail;
	}

	public TestRunReport removeRunReportDetail(TestRunReport runReportDetail) {
		getRunReportDetails().remove(runReportDetail);
		runReportDetail.setTestSuitRunReport(null);

		return runReportDetail;
	}

	public TestSuite getTestSuite() {
		return this.testSuite;
	}

	public void setTestSuite(TestSuite testSuite) {
		this.testSuite = testSuite;
	}

}