import os
import sys
import json
import glob
import timeit
import requests
import urllib.request
import numpy as np
from flask import Flask, request, redirect, jsonify
from flask_restful import Resource, Api, reqparse
from werkzeug.utils import secure_filename
from laserembeddings import Laser  # https://github.com/facebookresearch/LASER
from langdetect import detect
from gtts import gTTS
import pytesseract
from pytesseract import Output
import cv2
import itertools
import logging
import urllib3
import uuid 
import subprocess





urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from aws_helper import upload_file_to_s3, aws_image_to_text, aws_translate

# from skimage.filters import unsharp_mask

from scipy.ndimage.filters import median_filter

app = Flask(__name__)
app.secret_key = "secret key"

# wit config settings
WIT_MESSAGE_API_ENDPOINT = 'https://api.wit.ai/message'
WIT_SPEECH_API_ENDPOINT = 'https://api.wit.ai/speech'

english wit api settings
WIT_ACCESS_TOKEN_ENG = 'HD64NT7RHBEABVWMFRFGSYYYUAMIPJQX'
WIT_MESSAGE_HEADER_ENG = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_ENG)}
WIT_SPEECH_HEADER_ENG = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_ENG), 'Content-Type': 'audio/wav'}

# spanish wit api settings
WIT_ACCESS_TOKEN_SPA = 'HD64NT7RHBEABVWMFRFGSYYYUAMIPJQX'
WIT_MESSAGE_HEADER_SPA = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_SPA)}
WIT_SPEECH_HEADER_SPA = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_SPA), 'Content-Type': 'audio/wav'}

# german wit api settings
WIT_ACCESS_TOKEN_GER = 'HD64NT7RHBEABVWMFRFGSYYYUAMIPJQX'
WIT_MESSAGE_HEADER_GER = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_GER)}
WIT_SPEECH_HEADER_GER= {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKE#N_GER), 'Content-Type': 'audio/wav'}

english wit api settings
WIT_ACCESS_TOKEN_Italian = 'HD64NT7RHBEABVWMFRFGSYYYUAMIPJQX'
WIT_MESSAGE_HEADER_Italian = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_Italian)}
WIT_SPEECH_HEADER_Italian= {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_Italian), 'Content-Type': 'audio/wav'}

# spanish wit api settings
WIT_ACCESS_TOKEN_PORTUGUESE = 'HD64NT7RHBEABVWMFRFGSYYYUAMIPJQX'
WIT_MESSAGE_HEADER_PORTUGUESE = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_PORTUGUESE)}
WIT_SPEECH_HEADER_PORTUGUESE= {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_PORTUGUESE), 'Content-Type': 'audio/wav'}

# german wit api settings
WIT_ACCESS_TOKEN_French= 'HD64NT7RHBEABVWMFRFGSYYYUAMIPJQX'
WIT_MESSAGE_HEADER_French = {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_French)}
WIT_SPEECH_HEADER_French= {'Authorization': 'Bearer {}'.format(WIT_ACCESS_TOKEN_French), 'Content-Type': 'audio/wav'}


UPLOAD_FOLDER = "temp_upload"
ALLOWED_EXTENSIONS_AUDIO = set(['mp3', 'wav'])
ALLOWED_EXTENSIONS_IMAGE = set(["jpeg", "jpg", "bmp", "png"])

api = Api(app)

logging.basicConfig(format='%(asctime)s %(message)s', filename="app_flask_logs.log", level=logging.DEBUG)  #Using the basicConfig() function,
#we can set up the default handler so that debug messages are written to a file:
logging.getLogger(__name__)



class Default(Resource):   
    """
    Default page of application
    """ 
    def get(self):
        output="Welcome to VA APP"
        resp = jsonify({'message' : output})
        resp.status_code = 201
        return resp
        
class SentenceCompare(Resource):    
    """
    Check Sentence Similarity 
    """
    def get(self):
        output="Welcome to VA APP (SentenceCompare) - use HTTP POST method for api access"
        resp = jsonify({'message' : output})
        resp.status_code = 201
        return resp

    def post(self):
        """
        compare text sentences and generate contextual score using
        Tensorflow Universal Sentence Encoder
        [HTTP POST] function
        form-data inputs: 
        1)acttxt:  actual text, 
        2)exptxt: expected text seperated by pipe '|'

        """
        logging.debug("Anubhav")

        print("-------post call recieved--------")

        try:
            actual_text = request.form.get('acttxt')
            print("actual text: {0}".format(actual_text))

            expected_text = request.form.get('exptxt')

            lang_code = request.form.get('lang')
            print("lang code: {0}".format(lang_code))
        

            if not actual_text:
                resp = jsonify({'message' : 'No actual text (acttxt) found in input'})
                resp.status_code = 400
                return resp

            if not expected_text:
                resp = jsonify({'message' : 'No expected text (exptxt) found in input'})
                resp.status_code = 400
                return resp

            if not lang_code:
                resp = jsonify({'message' : 'No language code (lang=en for english, lang = es for spanish, lang = de fo German) found for input texts'})
                resp.status_code = 400
                return resp

            lsttxtexpected = expected_text.split("|")
            
            print("expected text: {0}".format(lsttxtexpected))

            print("-------checking context similarity from expected text--------")

            # check similarity from expected text
            output = compute_corr([actual_text], lsttxtexpected, lang=lang_code)
            print("output : {0}".format(output))       

            resp = jsonify({'message' : output})
            resp.status_code = 201
            return resp
        except Exception as ex:
            print(ex)
            logging.debug(ex)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            resp = jsonify({'message' : "Error has occured"})
            resp.status_code = 500
            return resp
    
class SpeechToText(Resource):
    """
    Speech To Text - Transcribe
    """    

    def get(self):
        output="Welcome to VA APP (Transcribe) - use HTTP POST method for api access"
        resp = jsonify({'message' : output})
        resp.status_code = 201
        return resp

    def post(self):
        """
        extract text from audio file input
        input = file,lang 
        returns text string
        uses wit.ai from audio to text transcribe service

        """
        
        print("-------post call recieved--------")

        try:

            if 'file' not in request.files:
                resp = jsonify({'message' : 'No file part in the request'})
                resp.status_code = 400
                return resp
            
            file = request.files['file']

            if file.filename == '':
                print("-------No file selected for uploading--------")
                resp = jsonify({'message' : 'No file selected for uploading'})
                resp.status_code = 400
                return resp
            
            lang_code = request.form.get('lang')


            if not lang_code:
                print("-------No language parameter (lang=en for english, lang = es for spanish, lang = de fo German) found in input--------")
                resp = jsonify({'message' : 'No language parameter (lang=en for english, lang = es for spanish, lang = de fo German) found in input'})
                resp.status_code = 400
                return resp

            if file and allowed_file(file.filename, ALLOWED_EXTENSIONS_AUDIO):
                clean_temp_folder()
                file_name = secure_filename(file.filename)
                file.save(os.path.join(UPLOAD_FOLDER, file_name))
                file_path = UPLOAD_FOLDER + "/" + file_name
                

                if (file_name.endswith(".mp3")):
                    print("-------converting mp3 to wav file ----------")
                    wav_file_path = UPLOAD_FOLDER + "/" + os.path.splitext(file_name)[0] + ".wav"
                    os.system("ffmpeg -i {mp3_file} {wav_file_name}".format(mp3_file=file_path, wav_file_name=wav_file_path))
                    file_name = os.path.splitext(file_name)[0] + ".wav"
                

                key_name = None
            
            print("transcribing audio file...") ##file name end with with wav
            output = text_from_audio(file_name, lang=lang_code)
            print("Output: {out}".format(out=output))
            clean_temp_folder()
            resp = jsonify({'message' : output})
            resp.status_code = 201
            return resp

        except Exception as ex:
            print(ex)
            logging.debug(ex)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            resp = jsonify({'message' : "Error has occured"})
            resp.status_code = 500
            return resp

class Rekognize(Resource):   
    """
    Extract Text from Image
    """
    def get(self):
        output="Welcome to VA APP (Rekognize)- use HTTP POST method for api access"
        resp = jsonify({'message' : output})
        resp.status_code = 201
        return resp 

    def post(self):
        """
        extract text from image file input
        returns text string
        uses custom tesseract implemantation

        """
        output = ""

        print("-------post call recieved--------")

        try:

            if 'file' not in request.files:
                resp = jsonify({'message' : 'No file part in the request'})
                resp.status_code = 400
                return resp
            
            file = request.files['file']

            if file.filename == '':
                resp = jsonify({'message' : 'No file selected for uploading'})
                resp.status_code = 400
                return resp
            
            if file and allowed_file(file.filename, ALLOWED_EXTENSIONS_IMAGE):
                file_name = secure_filename(file.filename)
                file.save(os.path.join(UPLOAD_FOLDER, file_name))
                file_path = UPLOAD_FOLDER + "/" + file_name
                print("extracting text from image...")
                output = extract_text_from_image(file.filename)
                key_name = None
                if not output:
                    ## AWS recoKnition serive fallback
                    print("image to text fallback --- using aws recognition ---")
                    s3_file_name = str(uuid.uuid4().hex[:10].lower()) + ".png"                    
                    s3_path = upload_file_to_s3(s3_file_name, file_path)
                    print("image uploaded to path: {0}".format(s3_path))
                    output = aws_image_to_text(s3_file_name)
            else:
                print("Check file extension. Allowed: {ext}".format(ext=ALLOWED_EXTENSIONS_IMAGE))

            
            print("Output: {out}".format(out=output))

            resp = jsonify({'message' : output})

        
            resp.status_code = 201
            return resp
        except Exception as ex:
            print(ex)
            logging.debug(ex)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            resp = jsonify({'message' : "Error has occured"})
            resp.status_code = 500
            return resp

class TextToSpeech(Resource):  
    """
    Text To Speech (TTS)
    """ 
    def get(self):
        output="Welcome to VA APP (TTS)- use HTTP POST method for api access"
        resp = jsonify({'message' : output})
        resp.status_code = 201
        return resp 

    def post(self):
        """
        Test To Speech (TTS) from input text and language code
        input txt, lang
        return S3 url of audio file (mp3)
        """
        output = ""

        print("-------post call recieved--------")

        try:
            lang_code = request.form.get('lang')
            txt = request.form.get('txt')


            if not lang_code:
                print("-------No language parameter (lang=en for english, lang = es for spanish, lang = de fo German) found in input--------")
                resp = jsonify({'message' : 'No language parameter (lang=en for english, lang = es for spanish, lang = de fo German) found in input'})
                resp.status_code = 400
                return resp
            
            if not txt:
                print("-------No text parameter (txt) found in input--------")
                resp = jsonify({'message' : 'No text parameter (txt) found in input'})
                resp.status_code = 400
                return resp
            
            output = text_to_speech(txt, lang=lang_code)
            
            print("Output: {out}".format(out=output))

            resp = jsonify({'message' : output})

            resp.status_code = 201
            return resp
        except Exception as ex:
            print(ex)
            logging.debug(ex)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            resp = jsonify({'message' : "Error has occured"})
            resp.status_code = 500
            return resp

class TranslateText(Resource):  
    """
    Translate Input text to another language
    """ 
    def get(self):
        output="Welcome to VA APP (TranslateText)- use HTTP POST method for api access"
        resp = jsonify({'message' : output})
        resp.status_code = 201
        return resp 

    def post(self):
        """
        TranslateText from input text (en) and language code of output (es,de)
        input txt, lang
        return translated txt and S3 url of audio file (mp3)
        """
        output = ""

        print("-------post call recieved--------")

        try:

            lang_code_source = request.form.get('lang_src')
            lang_code_target = request.form.get('lang_tgt')
            txt = request.form.get('txt')


            if not lang_code_source:
                print("-------No source-language parameter (lang_src = en for english, lang_src = es for spanish, lang_src = de fo German) found in input--------")
                resp = jsonify({'message' : 'No source language parameter (lang_src = en for english, lang_src = es for spanish, lang_src = de fo German) found in input'})
                resp.status_code = 400
                return resp
            
            if not lang_code_target:
                print("-------No target-language parameter (lang_tgt = en for english, lang_tgt = es for spanish, lang_tgt = de fo German) found in input--------")
                resp = jsonify({'message' : 'No target language parameter (lang_tgt = en for english, lang_tgt = es for spanish, lang_tgt = de fo German) found in input'})
                resp.status_code = 400
                return resp
            
            if not txt:
                print("-------No text parameter (txt) found in input--------")
                resp = jsonify({'message' : 'No text parameter (txt) found in input'})
                resp.status_code = 400
                return resp
            
            output_txt = aws_translate(txt, lang_src=lang_code_source, lang_tgt=lang_code_target)

            output_audio = text_to_speech(output_txt, lang=lang_code_target)

            resp = jsonify({'message' : output_txt, 'audio':output_audio})

            resp.status_code = 201
            return resp

        except Exception as ex:
            print(ex)
            logging.debug(ex)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            resp = jsonify({'message' : "Error has occured"})
            resp.status_code = 500
            return resp


api.add_resource(Default, '/')
api.add_resource(SentenceCompare, '/compare')
api.add_resource(SpeechToText, '/audio')
api.add_resource(Rekognize, '/image')
api.add_resource(TextToSpeech, '/tts')
api.add_resource(TranslateText, '/translate')


def compute_corr(input_text, expected_texts, lang="en"):
    """
    compute contextual simmilarity between actual and expected test input
    """
    output = []
    try:
        start = timeit.default_timer()
   
        laser = Laser()   
        lang_actual = detect(input_text[0])  
        in_emb = laser.embed_sentences(input_text[0], lang=lang)
       

        for exp_txt in expected_texts:  
            lang_expected = detect(exp_txt)
            ex_emb = laser.embed_sentences(exp_txt, lang=lang)           
            ex_emb_sq = np.squeeze(np.asarray(ex_emb))
            in_emb_sq = np.squeeze(np.asarray(in_emb))

            sim = cossim(in_emb_sq, ex_emb_sq)
            sim = "{0:.2f}".format(sim)    

            dict = {"actual" : input_text[0],  "expected":exp_txt, "lang":lang,  "score": sim}
            output.append(dict)
            result = "comparing message: Msg 1->{0}, Msg 2->{1}. => Sementic Similarity: {2}".format(input_text[0], exp_txt, sim)                
           

        stop = timeit.default_timer()
        print('Time taken: ', stop - start) 
        return output 

    except Exception as ex:
        print(ex)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        return output

def text_from_audio(file_name, lang="en"):
    try:
        
        file_path = UPLOAD_FOLDER + "/" + file_name

        with open(file_path, 'rb') as f:
            audio = f.read()      
        
        if lang == "en" or lang =="EN":
            #get response from wit.ai english speech api  
            resp_wit = requests.post(WIT_SPEECH_API_ENDPOINT, headers=WIT_SPEECH_HEADER_ENG, data=audio, verify=False)
        elif lang =="es" or lang =="ES":
            #get response from wit.ai spanish speech api  
            resp_wit = requests.post(WIT_SPEECH_API_ENDPOINT, headers=WIT_SPEECH_HEADER_SPA, data=audio, verify=False)
        elif lang =="de" or lang =="DE":
            #get response from wit.ai spanish speech api  
            resp_wit = requests.post(WIT_SPEECH_API_ENDPOINT, headers=WIT_SPEECH_HEADER_GER, data=audio, verify=False)
        else:
            print("language not supported")
            return None
        #Get the text
        data = json.loads(resp_wit.content)

        return data["_text"]


    except Exception as ex:
        print(ex)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)

def allowed_file(filename, allowed_exts):
	return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_exts

def clean_temp_folder():
    folderpath = UPLOAD_FOLDER + "/*"
    files = glob.glob(folderpath)
    for f in files:
        os.remove(f)

def cossim(v, w):
    return np.dot(v, w) / (np.linalg.norm(v) * np.linalg.norm(w))

def text_to_speech(txt, lang="en"):
    try:    
        file_name = str(uuid.uuid4().hex[:10].lower()) + ".mp3"
        file_path = os.path.join(UPLOAD_FOLDER,file_name)
        txt = txt.strip()
        
        print("converting text to speech...")
        speech = gTTS(text = txt, lang=lang, slow=False)
        print("saving to local...")
        speech.save(file_path)
        print("uploading to S3 and generating link")
        s3link = upload_file_to_s3(file_name=file_name, file_path=file_path)
        clean_temp_folder()
        return s3link

    except Exception as ex:
        print(ex)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        return ""
        
def unsharp(image, sigma, strength):

    # Median filtering
    image_mf = median_filter(image, sigma)

    # Calculate the Laplacian
    lap = cv2.Laplacian(image_mf,cv2.CV_64F)

    # Calculate the sharpened image
    sharp = image-strength*lap
    
    return sharp
    
def extract_text_from_image(input_file_name):

    try:

        input_file_path = UPLOAD_FOLDER + "/" + input_file_name
        
        img = cv2.imread(input_file_path)
        img_copy = img

        resizeFactor = 2
        img = cv2.resize(img, None, fx=resizeFactor, fy=resizeFactor)
        h, w, _ = img.shape


        fontScale = 0.8


        bw_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Median filtering
        gray_image_mf = median_filter(bw_image, 1)

        # Calculate the Laplacian
        lap = cv2.Laplacian(gray_image_mf,cv2.CV_64F)

        # Calculate the sharpened image
        sharp = bw_image - 0.7*lap


        ### text detection
        d = pytesseract.image_to_data(sharp, output_type=Output.DICT)

        
        n_boxes = len(d['text'])
        text_list=[]
        for i in range(n_boxes):
                if (len(d['text'][i])>1):                       
                        
                        text_list.append((d['top'][i], d['text'][i]))
 

        lines = [x[0] for x in text_list]
        lines=sorted(set(lines))
        print("lines: {0}".format(lines))
        grouped_lines=[]
        for k, g in itertools.groupby(lines, key=lambda n: n//10):
                grouped_lines.append(list(g))

    
        output_text=[]
        # i = 1
        for lines in grouped_lines:
                text_grp=[]
                for line in lines:
                        text = [v[1] for i, v in enumerate(text_list) if v[0] == line]
                        text_grp = text_grp + text
                print_txt = " ".join(text_grp)
                output_text.append(print_txt)            
            
 
        output_text_ = " ".join(output_text)

        return output_text_
    except Exception as ex:
        print(ex)
        logging.debug(ex)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        return "error has occured"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port="8082", threaded=True)
