package com.hcl.va.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.va.model.TestSuite;

public interface TestSuiteRepository extends JpaRepository<TestSuite, Integer> {

}
