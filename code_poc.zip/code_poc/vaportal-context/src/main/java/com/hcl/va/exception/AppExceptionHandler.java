package com.hcl.va.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.amazonaws.AmazonServiceException;
import com.hcl.va.bean.AppResponse;
import com.hcl.va.service.DataProcessingService;

@ControllerAdvice
public class AppExceptionHandler extends ResponseEntityExceptionHandler {
	private static final Logger log = LoggerFactory.getLogger(DataProcessingService.class);

	@ExceptionHandler(AmazonServiceException.class)
	public ResponseEntity<AppResponse> notFoundException(final AmazonServiceException e) {
		log.error("exception", e);
		return new ResponseEntity<>(new AppResponse("200", "AWS processing error"), HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ExceptionHandler(RestClientResponseException.class)
	public ResponseEntity<AppResponse> pythonAPIException(final RestClientResponseException e) {
		log.error("exception", e);
		return new ResponseEntity<>(new AppResponse("200", "Processing Failed"), HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<AppResponse> pythonAPIException(final Exception e) {
		log.error("exception", e);
		return new ResponseEntity<>(new AppResponse("200", "Error Occured"), HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<AppResponse> pythonAPIException(final RuntimeException e) {
		log.error("exception", e);
		return new ResponseEntity<>(new AppResponse("200", "Error Occured"), HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<AppResponse> handleUserNotFoundException(RecordNotFoundException ex, WebRequest request) {
		log.error("exception", ex);
		return new ResponseEntity<>(new AppResponse("400", "No matching test cases found"), HttpStatus.BAD_REQUEST);
	}

}
