import React from 'react';
import { render } from '@testing-library/react';
import App from './App';
describe('This will test MyComponent', () => {
test('Check Create Test Text', () => {
  const { getByText } = render(<App />);
  const linkElement = getByText(/Create Test/i);
  expect(linkElement).toBeInTheDocument();
});
test('Check Execute Text', () => {
  const { getByText } = render(<App />);
  const linkElement = getByText(/Execute/i);
  expect(linkElement).toBeInTheDocument();
});
test('Check Reports Text', () => {
  const { getByText } = render(<App />);
  const linkElement = getByText(/Report/i);
  expect(linkElement).toBeInTheDocument();
});
})