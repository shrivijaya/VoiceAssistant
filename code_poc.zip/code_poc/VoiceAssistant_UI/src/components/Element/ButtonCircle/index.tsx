import React from 'react'
import { Button } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
export const ButtonCircle = props => {

  return (
    <>
        <Button className="btn btn-circle btn-xl" disabled={props.disabled} >
          <FontAwesomeIcon icon={props.icon} />
        </Button>
    </>
  )
}

export default ButtonCircle