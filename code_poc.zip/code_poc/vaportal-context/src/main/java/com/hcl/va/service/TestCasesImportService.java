package com.hcl.va.service;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hcl.va.bean.TestCasesImportResponse;
import com.hcl.va.bean.TestData;
import com.hcl.va.exception.RecordNotFoundException;
import com.hcl.va.model.TestCase;
import com.hcl.va.repository.TestCaseRepository;
import com.hcl.va.transformer.TestCaseTransformer;
import com.hcl.va.util.FileUtils;
import com.opencsv.CSVReader;

@Service
public class TestCasesImportService {
	
	@Autowired
	private TestCaseRepository testCaseRepository;
	
	@Autowired
	private TestCaseTransformer testCaseTransformer;
	
	
	private List<Integer> testDataIdList;
	private List<TestData> testDataListResponse ;
	private Map<Integer,TestData> testDataMap = new HashMap<Integer,TestData>();
	
	private static final FileUtils FILE_UTIL = FileUtils.INSTANCE;
	
	public TestCasesImportResponse uploadTestCases(MultipartFile multipartFile) {
		File file = null;
		TestCasesImportResponse testCasesImportResponse = new TestCasesImportResponse();
		int lineNumber=0;
		testDataListResponse = new ArrayList<TestData>();
		try {
			file = FILE_UTIL.getFile(multipartFile);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
	        String[] nextRecord;
	        List<TestCase> testCaseList =  testCaseRepository.findAll();
			List<TestData> testDataList = testCaseList.stream().map(testCaseTransformer::transformBack).collect(Collectors.toList());
			
			for (TestData testData : testDataList) testDataMap.put(testData.getId(),testData);

			testDataIdList = testDataList.stream().map(testData->testData.getId()).collect(Collectors.toList());
			
	        while ((nextRecord = csvReader.readNext()) != null) {
	        	processCsvResponse(nextRecord, lineNumber);	        	
	        	lineNumber++;
	        }
	        testDataListResponse = testDataListResponse.stream().distinct().collect(Collectors.toList());
	        
	        testCasesImportResponse.setTestDataList(testDataListResponse);
	        csvReader.close();
	        
	       
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
	    if(testDataListResponse.size() == 0) {
	        throw new RecordNotFoundException("No matching test cases found");
	    }
	
        return testCasesImportResponse;
	}
	
	private void processCsvResponse(String[] attributes, int lineNumber) {
		List<String> testCaseIdList = new ArrayList<String>();
		
		
		
		for (String cell : attributes) { 
        	String[] cellArr = cell.split(",");
        	String[] testCaseIdArr = IntStream.range(0, cellArr.length).mapToObj(i -> cellArr[i]).toArray(String[]::new);
        	testCaseIdList = Arrays.asList(testCaseIdArr);        	
        } 
		
		for(String testCaseId : testCaseIdList) {
			if(testCaseId.contains("-")) {
				String[] testCaseIdRangeArr = testCaseId.split("-"); 
				int testCaseStart = Integer.valueOf(testCaseIdRangeArr[0]);
				int testCaseEnd = Integer.valueOf(testCaseIdRangeArr[1]);
				for (int index=testCaseStart; index<=testCaseEnd; index++) {
					if(testDataIdList!=null && testDataIdList.contains(index)) {
						TestData testData = testDataMap.get(index);
						if(lineNumber == 0) {
							testData.setIsChecked(true);
						}else {
							testData.setIsChecked(false);
						}
						testDataListResponse.add(testData);
					}
				}
			}else {
				if(testDataIdList!=null && testDataIdList.contains(Integer.valueOf(testCaseId))) {
					TestData testData = testDataMap.get(Integer.valueOf(testCaseId));
					if(lineNumber == 0) {
						testData.setIsChecked(true);
					}else {
						testData.setIsChecked(false);
					}
					testDataListResponse.add(testData);
				}
			}
		}		
	}
}
