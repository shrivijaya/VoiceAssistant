package com.hcl.va.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.hcl.va.bean.TranslateServiceResponse;
import com.hcl.va.model.TestCase;
import com.hcl.va.repository.TestCaseRepository;


@Service
public class TranslateService {
	
	@Autowired
	private PythonApiService pythonApiService;
	
	@Autowired
	private TestCaseRepository testDataRepository;
	
	@Value("${textToAudioTranslate.api.url}")
	private String textToAudioTranslateApiURL;
	
	@Value("${translate.targetLanguages}")
	private String translateTargetLanguages;
	
	private volatile List<String> testDataKeyList  = new ArrayList<String>();
	private volatile List<TestCase> translatedTestDataList = new ArrayList<TestCase>();
	
	public void translateTestCases() {
		try {
			System.out.println("starting translation");
			List<TestCase> testDataList = testDataRepository.findAll();			
			testDataKeyList = testDataList.stream().map(testdata->testdata.getTestCaseName()+"_"+testdata.getLanguage()).collect(Collectors.toList());
			
			final int chunkSize = 10;
			final AtomicInteger counter = new AtomicInteger();
			Collection<List<TestCase>> testDataCollectionOfSubList = testDataList.stream()
				    .collect(Collectors.groupingBy(it -> counter.getAndIncrement() / chunkSize))
				    .values();
			List<List<TestCase>> testDataListOfSubList = new ArrayList<List<TestCase>>(testDataCollectionOfSubList);
			ExecutorService executor = Executors.newFixedThreadPool(testDataListOfSubList.size());
			List<Callable<String>> callableTasks = new ArrayList<Callable<String>>();
			List<Future<String>> futureList = new ArrayList<Future<String>>();
			System.out.println("runnable task list");
			for(List<TestCase> testDataListElement : testDataListOfSubList) {
				Callable<String> callableTask =  ()-> {
					processTranslation(testDataListElement);
					return "success";
				};
				callableTasks.add(callableTask);
			}
			
			System.out.println("executing executor service");
			futureList = executor.invokeAll(callableTasks);
			for(Future<String> future : futureList) {
				String result = (String) future.get();
				System.out.println(result);
			}
			if(translatedTestDataList.size() > 0) {
				    testDataRepository.saveAll(translatedTestDataList);
			 }
			executor.shutdown();
		
		}catch(Exception ex) {
			ex.printStackTrace();
		}	
	}
	
	public void processTranslation(List<TestCase> testDataList) {
		try{
			String[]targetLanguageArr = translateTargetLanguages.split(",");
			List<String> targetLanguageList = Arrays.asList(targetLanguageArr);			
			for(TestCase testData : testDataList) {
				for(String targetLanguage : targetLanguageList) {
					if(testDataKeyList.contains(testData.getTestCaseName()+"_"+targetLanguage)) {
						continue;
					}
					
					TranslateServiceResponse inputTextTranslationResponse = callTextToAudioApi(testData.getInputText(), testData.getLanguage(), targetLanguage);
					TranslateServiceResponse outputTextTranslationResponse = callTextToAudioApi(testData.getExpectedOutputText(), testData.getLanguage(), targetLanguage);
					saveTranslatedTestCase(inputTextTranslationResponse, outputTextTranslationResponse, targetLanguage, testData);
				}	
			}					
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
		
	public TranslateServiceResponse callTextToAudioApi(String textInput, String inputLanguage, String targetLanguage) {
		TranslateServiceResponse translateServiceResponse = new TranslateServiceResponse();
		try {
			MultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();
			map.add("lang_tgt", targetLanguage);
			map.add("lang_src", inputLanguage);
			map.add("txt", textInput);
			ResponseEntity<String> response = pythonApiService.getResponseFrmPythonAPI(map, textToAudioTranslateApiURL);
			if (response.getBody() != null) {
				JsonObject jobj = new Gson().fromJson(response.getBody(), JsonObject.class);
				translateServiceResponse.setTranslatedText(jobj.get("message").toString());
				translateServiceResponse.setTranslatedAudioFilePath(jobj.get("audio").getAsString());	
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return translateServiceResponse;
	}
	
	public void saveTranslatedTestCase(TranslateServiceResponse inputTextTranslationResponse, TranslateServiceResponse outputTextTranslationResponse, String targetLanguage, TestCase testData) {
		TestCase translatedTestData = new TestCase();
		translatedTestData.setInputText(inputTextTranslationResponse.getTranslatedText());
		translatedTestData.setInputAudioUrl(outputTextTranslationResponse.getTranslatedAudioFilePath());
		translatedTestData.setExpectedOutputText(outputTextTranslationResponse.getTranslatedText());
		translatedTestData.setTestCaseName(testData.getTestCaseName());
		translatedTestData.setLanguage(targetLanguage);
		translatedTestData.setImgUrl(testData.getImgUrl());
		translatedTestData.setIsContextual(false);
		translatedTestData.setCreatedOn(LocalDateTime.now());
		
		translatedTestDataList.add(translatedTestData);
	}
	
	public TranslateServiceResponse callTextToAudioApiStubs(String textInput, String inputLanguage, String targetLanguage) {
		TranslateServiceResponse translateServiceResponse = new TranslateServiceResponse();
		translateServiceResponse.setTranslatedAudioFilePath("https://s3.us-west-1.amazonaws.com/audiofilesuswest1/e27cf6183d.mp3");
		translateServiceResponse.setTranslatedText("Hola, ¿cómo estás?");
		return translateServiceResponse;
	}
	
	/*public void processTranslation() {
	try{
		List<TestCase> testDataList = testDataRepository.findAll();
		testDataKeyList = testDataList.stream().map(testdata->testdata.getTestCaseName()+"_"+testdata.getLanguage()).collect(Collectors.toList());
		
		String[]targetLanguageArr = translateTargetLanguages.split(",");
		List<String> targetLanguageList = Arrays.asList(targetLanguageArr);			
		for(TestCase testData : testDataList) {
			for(String targetLanguage : targetLanguageList) {
				if(testDataKeyList.contains(testData.getTestCaseName()+"_"+targetLanguage)) {
					continue;
				}
				
				TranslateServiceResponse inputTextTranslationResponse = callTextToAudioApi(testData.getInputText(), testData.getLanguage(), targetLanguage);
				TranslateServiceResponse outputTextTranslationResponse = callTextToAudioApi(testData.getExpectedOutputText(), testData.getLanguage(), targetLanguage);
				saveTranslatedTestCase(inputTextTranslationResponse, outputTextTranslationResponse, targetLanguage, testData);
			}	
		}
		
		if(translatedTestDataList.size() > 0) {
			testDataRepository.saveAll(translatedTestDataList);
		}				
	}catch(Exception ex) {
		ex.printStackTrace();
	}
	
}*/
		
}
