import React from 'react';
import './index.css';
import {Navigation} from '../Navigation'

import { HashRouter as Router } from "react-router-dom";
export class Header extends React.Component {

   render() {
      return (
         <>
            <header>
               <div className="p-3 mb-2 color-info">

                  <i style={{fontSize:"24px"}} className="fa fa-apple">
                       &nbsp;Siri
                  </i>
                  <div style={{float:"right"}}>
                     <Router>  
                        <Navigation/>
                     </Router>
                  </div>
               </div>             
            </header>
         </>
      );
   }
}
