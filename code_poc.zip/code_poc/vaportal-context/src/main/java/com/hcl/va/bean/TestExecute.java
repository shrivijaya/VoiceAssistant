package com.hcl.va.bean;

public class TestExecute {

	private String testDataId;
	private String audioBase64;
	private String imageBase64;
	private String suiteId;
	private Integer runId;

	public String getSuiteId() {
		return suiteId;
	}

	public void setSuiteId(String suiteId) {
		this.suiteId = suiteId;
	}

	public String getTestDataId() {
		return testDataId;
	}

	public void setTestDataId(String testDataId) {
		this.testDataId = testDataId;
	}

	public String getAudioBase64() {
		return audioBase64;
	}

	public void setAudioBase64(String audioBase64) {
		this.audioBase64 = audioBase64;
	}

	public String getImageBase64() {
		return imageBase64;
	}

	public void setImageBase64(String imageBase64) {
		this.imageBase64 = imageBase64;
	}

	public Integer getRunId() {
		return runId;
	}

	public void setRunId(Integer runId) {
		this.runId = runId;
	}

}
