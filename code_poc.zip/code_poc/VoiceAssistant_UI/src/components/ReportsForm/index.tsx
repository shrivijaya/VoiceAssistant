import React from "react";
import { DateCarousel } from "../DateCarousel";
import { ReportList } from "../../models/Report";
import { connect } from "react-redux";
import { AppState } from "../../reducers/report";
import { fetchReports } from "../../actions/report";
import { ReportListTable } from "../ReportListTable";
import { NotifyService } from '../../services/NotifyService';
import { ReportService } from "../../services/ReportService";

import "./index.css";

interface OwnProps { }

interface StateProps {
  reportList: ReportList[];
}

interface State {
  reports: any;
  selected: any;
  isShow: boolean;
  ListPageloader: boolean;
  reportsBySuitId: Array<any>;
  testSuiteLoader: boolean;
  alertMessage: string,
  runReports: Array<any>,
}

interface DispatchProps {
  fetchReports: () => void;
}

interface AllProps extends StateProps, DispatchProps, OwnProps { }

export class ReportsForm extends React.Component<AllProps, State> {
  notify: NotifyService;
  reportService: ReportService;

  constructor(props) {
    super(props);
    this.handleChangeCaseSuite = this.handleChangeCaseSuite.bind(this);
    this.notify = new NotifyService();
    this.reportService = new ReportService();
  }

  state: State = {
    reports: [],
    selected: "",
    isShow: false,
    ListPageloader: false,
    reportsBySuitId: [],
    testSuiteLoader: false,
    alertMessage: "",
    runReports: []
  };

  componentDidMount() {
    this.setState({ testSuiteLoader: true })
    fetchReports()
      .reportList.then(response => {
        this.setState({ reports: response.data });
        this.setState({ testSuiteLoader: false })
      })
      .catch(() => {
        this.setState({ testSuiteLoader: false })
        this.setState({ alertMessage: 'Internal server error' })
      });
  }

  handleChangeCaseSuite = (event) => {
    this.setState({ reportsBySuitId: [] });
    this.setState({ runReports: [] });
    this.setState({ selected: event.target.value });
    this.getExecutedTestSuteBySuitId(event.target.value);

  };

  handleDateOnClick = (event) => {
    this.setState({ reportsBySuitId: [] });
    let currentTarget = event.target;
    let runId = currentTarget.getAttribute('data-id');
    this.getReportTestListBySuitId(this.state.selected, runId);
  };

  getExecutedTestSuteBySuitId(testSuiteId) {
    this.setState({ isShow: false })
    this.setState({ ListPageloader: true });
    this.reportService
      .getExecutedTestSuteBySuitId(testSuiteId)
      .then(response => {
        let rsData: any = response.data;
        this.setState({ runReports: rsData });
        if (rsData.length) {
          this.getReportTestListBySuitId(testSuiteId, rsData[0].id);
        } else {
          this.setState({ ListPageloader: false });
        }
      })
      .catch(() => {
        this.notify.notifyMessage("Internal server error ", 500);
        this.setState({ ListPageloader: false });
      });
  }
  getReportTestListBySuitId(testSuiteId, runId) {
    this.setState({ isShow: false })
    this.setState({ ListPageloader: true });
    this.reportService
      .getTestSuiteById(testSuiteId, runId)
      .then(response => {
        this.setState({ reportsBySuitId: response.data });
        this.setState({ ListPageloader: false });
      })
      .catch(() => {
        this.notify.notifyMessage("Internal server error ", 500);
        this.setState({ ListPageloader: false });
      });
  }

  render() {
    const htmlData = this.state.reports.map(report => {
      return (
        <option key={report.id} value={report.id}>
          {report.suiteName}
        </option>
      );
    });

    return (
      <>
        <div className="report-form">
          <div className="row">
            <div className="col-md-12">
              <div className="row">
                <div className="form-group col-md-9 test-cases">
                  {
                    this.state.alertMessage
                      ?
                      <div className="alert alert-danger" role="alert">
                        {this.state.alertMessage}
                      </div>
                      : ''
                  }
                  <b>Reports</b><br/><br/>
                </div>
                <div className="form-group col-md-9">
                  <select
                    name="test_cases"
                    value={this.state.selected}
                    onChange={this.handleChangeCaseSuite.bind(this)}
                    className="form-control"
                    required
                    aria-required="true"
                  >
                    <option value="" disabled>
                      {this.state.testSuiteLoader ? 'Loading.........' : 'Select Test Suite'}
                    </option>
                    {htmlData}
                  </select>
                </div>
              </div>
              {this.state.runReports.length ?
                <div className="row">
                  <div className="col-md-12">
                    <DateCarousel handleDateOnClick={this.handleDateOnClick} runReports={this.state.runReports} />
                  </div>
                </div>
                : null
              }
            </div>
          </div>
        </div>

        <div className="row">
          {this.state.selected ? (
            <ReportListTable
              selected={this.state.selected}
              loader={this.state.ListPageloader}
              reportsBySuitId={this.state.reportsBySuitId}
            />
          ) : null}
        </div>
      </>
    );
  }
}

export const ConnectedReportForm = connect<
  StateProps,
  DispatchProps,
  OwnProps,
  AppState
>(
  state => ({
    reportList: state.reportList
  }),
  dispatch => ({
    fetchReports: () => dispatch(fetchReports())
  })
)(ReportsForm);
