import { combineReducers } from 'redux'
import { ReportReducer } from '../reducers/report'

export default combineReducers({
    ReportReducer,
})