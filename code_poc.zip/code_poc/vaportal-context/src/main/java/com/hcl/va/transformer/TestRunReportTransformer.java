package com.hcl.va.transformer;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.hcl.va.bean.TestRunReportBean;
import com.hcl.va.model.TestRunReport;

@Component
public class TestRunReportTransformer {
	
	public TestRunReport transform(TestRunReportBean runReportBean) {
		TestRunReport runReport = new TestRunReport();
		BeanUtils.copyProperties(runReportBean, runReport, "testSuitRunReport", "testCase", "recordedImageUrl",
				"recordedAudioUrl", "inputImgTxt", "inputImageUrl", "inputAudioUrl", "expectedOutputText", "createdOn",
				"comparisonResponse", "childId");
		runReport.setRecordedImageUrl(runReportBean.getRecordedImageURL());
		runReport.setRecordedAudioUrl(runReportBean.getRecordedAudioURL());
		runReport.setInputImgTxt(runReportBean.getInputImageTxt());
		runReport.setInputImageUrl(runReportBean.getInputImgURL());
		runReport.setInputAudioUrl(runReportBean.getInputAudioURL());
		runReport.setExpectedOutputText(runReportBean.getExpectedOutputTxt());
		runReport.setCreatedOn(runReportBean.getCreatedDate());
		runReport.setComparisonResponse(runReportBean.getActualResponse());
		return runReport;

	}
	
	public TestRunReportBean transformBack(TestRunReport runReport) {
		TestRunReportBean runReportBean = new TestRunReportBean();
		BeanUtils.copyProperties(runReport, runReportBean, "suiteId", "runId", "testCaseId", "testCaseName",
				"recordedImageURL", "recordedAudioURL", "inputImageTxt", "inputImgURL", "inputAudioURL",
				"expectedOutputTxt", "createdDate", "actualResponse");
		runReportBean.setRecordedImageURL(runReport.getRecordedImageUrl());
		runReportBean.setRecordedAudioURL(runReport.getRecordedAudioUrl());
		runReportBean.setInputImageTxt(runReport.getInputImgTxt());
		runReportBean.setInputImgURL(runReport.getInputImageUrl());
		runReportBean.setInputAudioURL(runReport.getInputAudioUrl());
		runReportBean.setExpectedOutputTxt(runReport.getExpectedOutputText());
		runReportBean.setCreatedDate(runReport.getCreatedOn());
		runReportBean.setActualResponse(runReport.getComparisonResponse());
		Optional.ofNullable(runReport.getTestCase()).ifPresent(testCase -> {
			runReportBean.setTestCaseId(testCase.getId());
			runReportBean.setTestCaseName(testCase.getTestCaseName());
		});
		Optional.ofNullable(runReport.getTestSuitRunReport()).ifPresent(testSuitRunReport -> {
			runReportBean.setSuiteId(testSuitRunReport.getTestSuite().getId());
			runReportBean.setRunId(testSuitRunReport.getId());
		});
		return runReportBean;

	}

}
