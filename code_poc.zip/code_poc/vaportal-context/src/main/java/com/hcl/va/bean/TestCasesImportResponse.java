package com.hcl.va.bean;

import java.util.List;

public class TestCasesImportResponse {
	private List<TestData> testDataList;

	public List<TestData> getTestDataList() {
		return testDataList;
	}

	public void setTestDataList(List<TestData> testDataList) {
		this.testDataList = testDataList;
	}
	
	

}
