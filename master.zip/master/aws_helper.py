#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
   VA test automation 
   __file__        = "aws_helper.py"
   __author__      = "Anubhav Agarwal"
   __copyright__   = "Copyright 2020, HCL Technologies India"
   __file_version__     = "1.0.0"   
   __python_ver__  = "3.6"
   __date__        ="02-Jan-20"

"""

import boto3
from boto3.s3.transfer import S3Transfer
from botocore.exceptions import ClientError
import os, sys, json, time

#----config settings AWS -------------
AWS_ACCESS_KEY_ID = '######################'
AWS_SECRET_ACCESS_KEY = '##########################'
AWS_REGION = "us-west-1"
bucket_name = "audiofilesuswest1"


#----upload files to S3 -     -------------
def upload_file_to_s3(file_name, file_path, key_name=None):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param key_name: S3 object name. If not specified then same as file_name
    :return: True if file was uploaded, else False
    """

    # bucket_name = "audiofilesuswest1"

    # If S3 object_name was not specified, use file_name
    if key_name is None:
        key_name = file_name

    try:
        # Upload the file
        s3_client = boto3.client('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key= AWS_SECRET_ACCESS_KEY, region_name=AWS_REGION)
        
        transfer = S3Transfer(s3_client)

        transfer.upload_file(file_path, bucket_name, key_name,
                        extra_args={'ACL': 'public-read'})
                        
        file_url = '%s/%s/%s' % (s3_client.meta.endpoint_url, bucket_name, key_name)

        # print(file_url)

    except ClientError as e:
        # logging.error(e)
        print(e)
        return False
    return file_url


#----read info from transcribe json output-     -------------
def get_transcript_S3_json(bucket_name, object_name):
    """Retrieve an object from an Amazon S3 bucket

    :param bucket_name: string
    :param object_name: string
    :return: botocore.response.StreamingBody object. If error, return None.
    """

    # Retrieve the object
    s3_resource = boto3.resource('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key= AWS_SECRET_ACCESS_KEY, region_name=AWS_REGION)

    try:
        content_object  = s3_resource.Object(bucket_name, object_name)
        file_content = content_object.get()['Body'].read().decode('utf-8')
        json_content = json.loads(file_content)
        # print(json_content['results'])
        # print(json_content['results']["transcripts"])
        transcript = json_content['results']["transcripts"][0]["transcript"]
        # print(transcript)
        


    except ClientError as e:
        # AllAccessDisabled error == bucket or object not found
        # logging.error(e)
        return None
    # Return an open StreamingBody object
    return transcript


#----audio to text-  using AWS transcribe Api -------------
def aws_speech_to_text(job_name, s3_file_uri, file_extension ):
    # bucket_name = "audiofilesuswest1"

    try:
        transcribe = boto3.client('transcribe', aws_access_key_id=AWS_ACCESS_KEY_ID,
                aws_secret_access_key= AWS_SECRET_ACCESS_KEY, region_name=AWS_REGION)

        transcribe.start_transcription_job(
        TranscriptionJobName=job_name,
        Media={'MediaFileUri': s3_file_uri},
        MediaFormat=file_extension,
        LanguageCode='en-US',
        OutputBucketName =bucket_name)

        while True:
            status = transcribe.get_transcription_job(TranscriptionJobName=job_name)
            if status['TranscriptionJob']['TranscriptionJobStatus'] in ['COMPLETED', 'FAILED']:
                break
            print("Not ready yet...")
            time.sleep(5)

        
        json_output_uri = status['TranscriptionJob']['Transcript']['TranscriptFileUri']
        
        filename = json_output_uri[json_output_uri.rfind("/")+1:]

        print("filename : {0}".format(filename))

        print("parsing transcript from json output")

        transcript = get_transcript_S3_json( bucket_name, filename)

        return transcript
    except Exception as ex:
        print("Exception:")
        print(ex)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        return False


#----image text extraction-  using AWS recognition Api -------------
def aws_image_to_text(photo):
    # bucket_name = "audiofilesuswest1"

    reko_client = boto3.client('rekognition', aws_access_key_id=AWS_ACCESS_KEY_ID,
                aws_secret_access_key= AWS_SECRET_ACCESS_KEY, region_name=AWS_REGION)

    response=reko_client.detect_text(Image={'S3Object':{'Bucket':bucket_name,'Name':photo}})
    
    textDetections=response['TextDetections']
    all_words = ""
    
    for text in textDetections:
        if text['Type'] == "WORD":
            all_words = all_words + " " + text['DetectedText']
    
    print ('Detected text\n----------')
    print(all_words)
    print ('\n----------')
    return all_words

def aws_translate(input_txt, lang_src, lang_tgt):
    try:
        trans_client = boto3.client('translate', aws_access_key_id=AWS_ACCESS_KEY_ID,
                    aws_secret_access_key= AWS_SECRET_ACCESS_KEY, region_name=AWS_REGION)
        print("---translating using AWS translate ---")
        result = trans_client.translate_text(Text=input_txt, 
                SourceLanguageCode=lang_src, TargetLanguageCode=lang_tgt)
        return result.get('TranslatedText')
    except Exception as e:
        print("---error has occured ---")
        print(e)
        return ""
