import ExeMsg from '../static/conf/executionMessages.json';
import { UtilityService } from './UtilityService';

export interface IWindow extends Window {
    webkitSpeechRecognition: any;
}
const CONF = {
    AUDIO_WAIT: 7,
    IMAGE_WAIT: 4,
};
export class MediaService {
    //    spoken:string;
    inputvalue: any;
    recognition: any;
    synth: any;
    mediaDevicesObj:any;
    constructor(callerObj) {
        const { webkitSpeechRecognition, speechSynthesis }: IWindow = <IWindow><unknown>window;
        try {
            this.mediaDevicesObj = navigator.mediaDevices;
            this.synth = speechSynthesis;
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.maxAlternatives = 1;
            this.recognition.lang = 'en-US';
            this.recognition.onstart = () => {
                this.recognition.recognizing = true;
                callerObj.setState({ message: ExeMsg[2].message, status: ExeMsg[2].messageCode });
            };
            this.recognition.onerror = event => {
                callerObj.setState({ message: "Something went wrong. Try reloading the page.", status: -1 });;
            }
            this.recognition.onnomatch = event => {
                callerObj.setState({ message: "no match", status: -2 });
            }
        } catch (error) {
            console.log(error);
        }
    }

    startRrecognition(callerObj) {
        return new Promise(resolve => {
            let recognition = this.recognition;
            let voiceInput = "";
            recognition.start();

            recognition.onresult = event => {
                var interim_transcript = '';
                for (var i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        var result = event.results[i][0].transcript;

                        console.log("onresult call");
                        resolve(result);
                        recognition.stop();

                    } else {
                        interim_transcript += event.results[i][0].transcript;
                        console.log("interim_transcript:" + interim_transcript);
                    }
                }
            };
            /*
            recognition.onspeechend = function() {
                console.log("onspeechend call");
               recognition.stop();
               resolve();   
             };*/
        });
    }
    getSynthObj() {
        return this.synth;
    }
    getInputvalue() {
        return this.inputvalue;
    }
    playCommand(audioUrl) {
        return new Promise(resolve => {
            const audio = new Audio(audioUrl);
            audio.play();
            audio.onended = () => {
                resolve();
            }
        });
    }
    getTextToVoice(synth: any, text: string) {
        return new Promise(resolve => {
            const utter = new SpeechSynthesisUtterance(text);
            const voices = speechSynthesis.getVoices();
            utter.voice = voices[1]
            synth.speak(utter);
            utter.onend = event => {
                resolve();
            }
        });
    }

    async getVideoSnapshot(_self,waitTime=null) {
        return new Promise(async resolve => {
            this.mediaDevicesObj.getUserMedia({ video: true, audio: false })
                .then((stream) => {
                    _self.video = _self.refs.video;
                    _self.video.srcObject = stream;
                    _self.webcamStream = stream;
                    _self.video.play();
                    _self.video.onplaying = async function () {                     
                        await UtilityService.delay(waitTime!=null?waitTime:CONF.IMAGE_WAIT);

                        _self.setState({ enbleVideo: false });
                        _self.canvas = _self.refs.canvas;
                        _self.canvas.width = 400;
                        _self.canvas.height = 300;
                        _self.ctx = _self.canvas.getContext('2d');
                        _self.ctx.drawImage(_self.video, 0, 0, _self.canvas.width, _self.canvas.height);
                        var imageData = _self.canvas.toDataURL();
                        let imageBlobData ="";// await new Promise(resolve => _self.canvas.toBlob(imageData, 'image/png'));
                        if (_self.webcamStream != null) {
                            _self.webcamStream.getTracks().map(function (val) {
                                val.stop();
                               // _self.setState({ showTimer: false });
                                resolve({imageData,imageBlobData});
                            });
                        }
                    };
                })
                .catch((err) => {
                    console.log("An error occurred: " + err);
                });
        });
    }
    async startCamra(_self:any) {
        return new Promise(async resolve => {
            this.mediaDevicesObj.getUserMedia({ video: true, audio: false })
                .then((stream) => {
                    _self.video = _self.refs.video;
                    _self.video.srcObject = stream;
                    _self.webcamStream = stream;
                    _self.video.play();
                    let webcamStream =_self.webcamStream;
                    let video= _self.video
                    resolve({webcamStream,video});  
      
                })
                .catch((err) => {
                    console.log("An error occurred: " + err);
                });
        });
    }
    async captureImage(_self:any) {
        return new Promise(async resolve => {
            _self.setState({ enbleVideo: false });
            _self.canvas = _self.refs.canvas;
            _self.canvas.width = 400;
            _self.canvas.height = 300;
            _self.ctx = _self.canvas.getContext('2d');
            _self.ctx.drawImage(_self.video, 0, 0, _self.canvas.width, _self.canvas.height);
            var imageData = _self.canvas.toDataURL();
            let imageBlobData ="";// await new Promise(resolve => _self.canvas.toBlob(imageData, 'image/png'));
            if (_self.webcamStream != null) {
                _self.webcamStream.getTracks().map(function (val) {
                    val.stop();
                   // _self.setState({ showTimer: false });
                    resolve({imageData,imageBlobData});
                });
            }
        });
    }

    getAudioSnapshot(callerObj) {
        return new Promise(async resolve => {
            navigator.mediaDevices.getUserMedia({ video: false, audio: true })
                .then((stream) => {
                    const mediaRecorder = new MediaRecorder(stream);
                    const audioChunks = [];
                    mediaRecorder.ondataavailable = function (e) {
                        audioChunks.push(e.data);
                    }
                    const start = () => {
                        mediaRecorder.start();
                    };
                    const stop = () =>
                        new Promise(resolve => {
                            mediaRecorder.stop();
                            mediaRecorder.onstop = () => {
                                const audioBlob = new Blob(audioChunks, {
                                    type: 'audio/wav',
                                    endings: 'native'
                                });
                                const audioUrl = URL.createObjectURL(audioBlob);
                                stream.getAudioTracks().forEach(function (track) {
                                    track.stop();
                                });
                                resolve(audioBlob);
                            }
                        });
                    resolve({ start, stop });
                })
                .catch((err) => {
                    console.log("An error occurred: " + err);
                });
        });
    }
    getFileBolb = (audioData) => {
        return new Promise(resolve => {
            var reader = new FileReader();
            var base64data;
            reader.readAsDataURL(audioData);
            reader.onloadend = function () {
                base64data = reader.result;
                resolve(base64data)
            }
        });
    }
    getFileData = (audioData) => {
        return new Promise(resolve => {
            var reader = new FileReader();
            var base64data;
            reader.readAsDataURL(audioData);
            reader.onloadend = function () {
                base64data = reader.result;
                resolve(base64data)
            }
        });
    }
    downloadFileFromBlob(fileURL: string, filename: string) {
        // var csvURL = window.URL.createObjectURL(audioBlob);
        let tempLink = document.createElement('a');
        tempLink.href = fileURL;
        tempLink.setAttribute('download', filename);
        tempLink.click();
    };
    startAudioRecording = (callerObj,waitTime=null) => {
        return new Promise(async resolve => {
            const recorder: any = await this.getAudioSnapshot(callerObj);
            recorder.start();
            await callerObj.delay(waitTime?waitTime:CONF.AUDIO_WAIT);
            const audioData = await recorder.stop();
            let audioFileData = await this.getFileData(audioData);
            callerObj.setState({ message: ExeMsg[3].message, status: ExeMsg[3].messageCode });
            resolve({ audioFileData, audioData });
        });
    }

}
