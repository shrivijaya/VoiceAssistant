package com.hcl.va.bean;

import java.time.LocalDateTime;


public class TestRunReportBean {

	private Integer runId;
	
	private Integer id;

	private Integer testCaseId;

	private Integer suiteId;

	private String inputText;

	private String expectedOutputTxt;

	private String testCaseName;

	private String result;

	private LocalDateTime createdDate;

	private String recordedAudioURL;

	private String recordedImageURL;

	private String recordedImageTxt;

	private String recordedAudioTxt;

	private Double score;

	private Double audioScore;

	private Double imageScore;

	private String inputImgURL;

	private String inputAudioURL;

	private String inputImageTxt;

	private String actualResponse;

	/*
	 * @OneToMany(cascade=CascadeType.ALL, mappedBy = "testRunReport", fetch =
	 * FetchType.EAGER) private Set<ActualResponse> actualResponse;
	 * 
	 * public Set<ActualResponse> getActualResponse() { return actualResponse; }
	 * 
	 * public void setActualResponse(Set<ActualResponse> actualResponse) {
	 * this.actualResponse = actualResponse; }
	 */

	public Integer getRunId() {
		return runId;
	}

	public void setRunId(Integer runId) {
		this.runId = runId;
	}

	public Integer getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(Integer testCaseId) {
		this.testCaseId = testCaseId;
	}

	public Integer getSuiteId() {
		return suiteId;
	}

	public void setSuiteId(Integer suiteId) {
		this.suiteId = suiteId;
	}

	public String getActualResponse() {
		return actualResponse;
	}

	public void setActualResponse(String actualResponse) {
		this.actualResponse = actualResponse;
	}

	public String getInputImageTxt() {
		return inputImageTxt;
	}

	public void setInputImageTxt(String inputImageTxt) {
		this.inputImageTxt = inputImageTxt;
	}

	public String getInputImgURL() {
		return inputImgURL;
	}

	public void setInputImgURL(String inputImgURL) {
		this.inputImgURL = inputImgURL;
	}

	public String getInputAudioURL() {
		return inputAudioURL;
	}

	public void setInputAudioURL(String inputAudioURL) {
		this.inputAudioURL = inputAudioURL;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getTestCaseName() {
		return testCaseName;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public String getInputText() {
		return inputText;
	}

	public void setInputText(String inputText) {
		this.inputText = inputText;
	}

	public String getExpectedOutputTxt() {
		return expectedOutputTxt;
	}

	public void setExpectedOutputTxt(String expectedOutputTxt) {
		this.expectedOutputTxt = expectedOutputTxt;
	}

	public Double getAudioScore() {
		return audioScore;
	}

	public void setAudioScore(Double audioScore) {
		this.audioScore = audioScore;
	}

	public Double getImageScore() {
		return imageScore;
	}

	public void setImageScore(Double imageScore) {
		this.imageScore = imageScore;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRecordedAudioURL() {
		return recordedAudioURL;
	}

	public void setRecordedAudioURL(String recordedAudioURL) {
		this.recordedAudioURL = recordedAudioURL;
	}

	public String getRecordedImageURL() {
		return recordedImageURL;
	}

	public void setRecordedImageURL(String recordedImageURL) {
		this.recordedImageURL = recordedImageURL;
	}

	public String getRecordedImageTxt() {
		return recordedImageTxt;
	}

	public void setRecordedImageTxt(String recordedImageTxt) {
		this.recordedImageTxt = recordedImageTxt;
	}

	public String getRecordedAudioTxt() {
		return recordedAudioTxt;
	}

	public void setRecordedAudioTxt(String recordedAudioTxt) {
		this.recordedAudioTxt = recordedAudioTxt;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

}
