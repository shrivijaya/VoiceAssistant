import React from 'react';
export class Footer extends React.Component {

   render() {
      return (
         <>
            <footer className="">
               &nbsp;
            </footer>
         </>
      );
   }
}
