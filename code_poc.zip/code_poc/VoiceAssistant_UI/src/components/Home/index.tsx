import React from 'react';
import { Execution } from '../Execution';
export class Home extends React.Component {
   componentDidMount() {

   }

   render() {
      return (
         <>
           Home Comming
            <Execution></Execution>
         </>

      );
   }
}
