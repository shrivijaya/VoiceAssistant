import React from 'react';
import { render } from '@testing-library/react';
import {CategoryForm} from './index';
import {create, act} from 'react-test-renderer';

describe('CategoryForm', () => {
    let container,instance;
 
    beforeEach(() => {
       container  = create(<CategoryForm />);
       instance = container.getInstance();
      });
    test('handleChange', () => {
        const mockEvent = {
            target: {
              name: "title",
              value: "test"
            }
          };
          const expected = 'test';
          instance.handleChange("command",mockEvent);         
          expect(instance.state.command).toEqual(expected);
    });
}) 