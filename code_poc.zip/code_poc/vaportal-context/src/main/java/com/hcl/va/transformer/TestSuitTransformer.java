package com.hcl.va.transformer;

import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.hcl.va.bean.TestSuiteBean;
import com.hcl.va.model.TestCase;
import com.hcl.va.model.TestSuite;

@Component
public class TestSuitTransformer {
	
	public TestSuite transform(TestSuiteBean testSuitBean) {
		TestSuite testSuit = new TestSuite();
		BeanUtils.copyProperties(testSuitBean, testSuit, "testSuitName","testSuitRunReports","testSuiteMappings","createdOn","testCases");
		testSuit.setTestSuitName(testSuitBean.getSuiteName());
		return testSuit;
		
	}
	
	public TestSuiteBean transformBack(TestSuite testSuit) {
		TestSuiteBean testSuitBean = new TestSuiteBean();
		BeanUtils.copyProperties(testSuit, testSuitBean, "testCaseIds", "suiteName", "createdDate");
		testSuitBean.setSuiteName(testSuit.getTestSuitName());
		String testCaseIds = StringUtils.EMPTY;
		if (null != testSuit.getTestCases()) {
			testCaseIds = testSuit.getTestCases().stream().map(TestCase::getId).map(String::valueOf).collect(Collectors.joining(","));
		}
		testSuitBean.setTestCaseIds(testCaseIds);
		testSuitBean.setCreatedDate(testSuit.getCreatedOn());
		return testSuitBean;

	}

}
