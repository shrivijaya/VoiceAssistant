import React, { PureComponent } from 'react';
import memoize from 'memoize-one';
import DataTable from 'react-data-table-component';

const columns:any = memoize(() => [

  {
    name: 'Name',
    selector: 'name',
    sortable: true,
    grow: 2,
  },
  {
    name: 'Type',
    selector: 'type',
    sortable: true,
  }

]);
const customStyles:any = {

  rows: {
     style: {
        border: "none !important",
        color: "#959595",
     }
  },
  headCells: {
     style: {
        fontSize: '12px',
        fontWeight: 500,
        color: "#028AA4",

     },
     activeSortStyle: {
        color: "#028AA4",
        '&:focus': {
           outline: 'none',
        },
        '&:hover:not(:focus)': {
           color: "#028AA4",
        },
     },
     inactiveSortStyle: {
        '&:focus': {
           outline: 'none',
           color: "#028AA4",
        },
        '&:hover': {
           color: "#028AA4",
        },
     },
  },
  header: {
     style: {
        color: "#028AA4",
     },
  }
};
export class TableFromDataTable extends PureComponent<{data,onSelectChange}> {
  
  state = {
    selectedRows: [],
  };

  handleChange = state => {
    //this.setState({ selectedRows: state.selectedRows });
    this.props.onSelectChange(state.selectedRows);
  }

  render() {
    
    return (
      <DataTable
        title="Desserts"
        data={this.props.data}
        columns={columns()}
        customStyles={customStyles}
        onSelectedRowsChange={this.handleChange}
        selectableRows
        pagination
        fixedHeader
        fixedHeaderScrollHeight="300px"
      />
    );
  }
}
