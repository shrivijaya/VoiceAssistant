import * as React from 'react'
import {NavLink}  from 'react-router-dom';
import {  Nav } from "react-bootstrap";

import './index.css';

export class Navigation extends React.Component {
    render() {
        return (
            <>
                <NavLink exact={true} activeStyle={{fontWeight: "bold"}} to='/'>Create Test Case</NavLink>
                <NavLink activeStyle={{fontWeight: "bold"}} to='/execution'>Execute</NavLink>
                <NavLink activeStyle={{fontWeight: "bold"}} to='/reports'>Report</NavLink>
            </>
        )
    }
}