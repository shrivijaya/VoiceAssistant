import axios from 'axios';

const API_URL = process.env.REACT_APP_API_SERVER_NAME + ':' + process.env.REACT_APP_API_SERVER_HOST + "/api/";

export class ExecutionService {
    getTestData(callerObj) {
        axios.get(API_URL + 'getTestData')
            .then(response => {
                (response.data).forEach(el => {
                    el.isChecked = false;
                    el.value = el.testCaseName ? el.testCaseName : 'Test';
                    el.executionStatus = "In-Queue";
                });
                callerObj.setState({ testCases: response.data });
            })
            .catch(error => {
                callerObj.setState({ testCases: this.getDumyData() });
                console.log(error);
            }).finally(() => {             
                callerObj.setState({ testCasesLoader: false });
            });
    }
    executeTestUpload(data) {
        console.log(data);
        let header = {
            headers: {
                'Content-Type': 'application/json',
            }
        };
        let formBody = [];
        let cMediaResponse = {};
        formBody.push({
            runId:data.runId,
            testDataId: data.testCaseId,
            suiteId: data.testSuiteId,
            audioBase64: data.mediaResponse.audioData.audioFileData,
            imageBase64: data.mediaResponse.imageData.imageData,          
        });

        if (data.childMediaResponse) {
            formBody.push({
                testDataId: data.childMediaResponse.childTestCaseId,
                suiteId: data.testSuiteId,
                audioBase64: data.childMediaResponse.audioData.audioFileData,
                imageBase64: data.childMediaResponse.imageData.imageData
            });
        }


        let url = API_URL + 'executeTest';
        return axios.post(url, formBody, header);
    }
    getDumyData() {
        return [{
            inputText: "how is weather today",
            expectedOutput: "weather is awesome | weather is very hot",
            imgToText: "curious about am area-filling text rendering options",
            id: 1,
            imgUrl: "https://s3.ap-south-1.amazonaws.com/mytesting.online/vrkIj.png",
            inputAudioURL: "",
            language: "en",
            value: "how is weather today",
            executionStatus: "In-Queue",
            isChecked: false
        }
        ]
    }
    createTestSuite(data) {
        const header = {
            headers: {
                'Content-Type': 'application/json',
            }
        };
        return axios.post(API_URL + 'testSuite', data, header);
    }

    getTestSuiteData(callerObj) {
        axios.get(API_URL + 'getTestSuiteNames')
            .then(response => {
                console.log(response.data)
                callerObj.setState({ suiteNames: response.data });
            })
            .catch(error => {
                callerObj.setState({ testCases: [] });
                console.log(error);
            });
    }

    getSelectedTestSuiteData(id) {
        return axios.get(API_URL + '/getTestSuite?id=' + id);
    }

    uploadTestCases(data) {
        const header = {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        };
        return axios.post(API_URL + 'uploadTestCases', data, header);

    }
}