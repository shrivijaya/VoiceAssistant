package com.hcl.va.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.va.model.TestSuitRunReport;

@Repository
public interface TestSuitRunReportRepository  extends JpaRepository<TestSuitRunReport, Integer> {
	
	List<TestSuitRunReport> findByTestSuite_IdOrderByCreatedOnDesc(Integer testSuiteId);

}
