import React from 'react';
interface State {
  seconds: any,
  value: any,
  isClicked: boolean
}
export class Timer extends React.Component<{ value, seconds }, State> {
  static getSecToMS(sec){return sec*1000;}
  intervalHandle: NodeJS.Timeout;
  secondsRemaining: number;
  mounted:boolean;
  constructor(prop) {
    super(prop);
    this.tick = this.tick.bind(this);
    this.startCountDown = this.startCountDown.bind(this);
    this.mounted  = false;
  }
  state: State = {
    seconds: this.props.seconds,
    value: this.props.value,
    isClicked: false

  }
  startCountDown() {
    this.intervalHandle = setInterval(this.tick, 1000);
    let time = this.state.value;
    this.secondsRemaining = time ?time * 60:this.state.seconds;
    this.setState({ isClicked: true })
  }
  tick() {
    var min = Math.floor(this.secondsRemaining / 60);
    var sec = this.secondsRemaining - (min * 60);
    this.setState({
      value: min,
      seconds: sec,
    })

    if (sec < 10) {
      this.setState({
        seconds: "0" + this.state.seconds,
      })

    }

    if (min < 10) {
      this.setState({
        value: "0" + min,
      })

    }

    if (min === 0 && sec === 0) {
      clearInterval(this.intervalHandle);
      this.setState({isClicked:false})
    }
    this.secondsRemaining--
  }
  componentDidMount() {
    this.mounted  = true;
    this.mounted && this.startCountDown();
  }
  componentWillMount() {
    this.mounted  = false;
  }
  render() {
    return (
      <>
      { this.state.isClicked &&
      <div>
        <h6>{this.state.value<1? '00' :this.state.value}:{this.state.seconds}</h6>
      </div>
    }
    </>
    );
  }
}

