package com.hcl.va.transformer;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcl.va.bean.TestSuitRunReportBean;
import com.hcl.va.model.TestSuitRunReport;

@Component
public class TestSuitRunReportTransformer {
	
	@Autowired
	private TestSuitTransformer testSuitTransformer;
	
	public TestSuitRunReport transform(TestSuitRunReportBean runReportBean) {
		TestSuitRunReport runReport   = new TestSuitRunReport();
		BeanUtils.copyProperties(runReportBean, runReport,"runReportDetails","testSuite" );
		return runReport;
		
	}
	
	public TestSuitRunReportBean transformBack(TestSuitRunReport runReport) {
		TestSuitRunReportBean runReportBean = new TestSuitRunReportBean();
		BeanUtils.copyProperties(runReport, runReportBean, "testSuiteBean");
		Optional.ofNullable(runReport.getTestSuite()).ifPresent(testSuite -> {
			runReportBean.setTestSuiteBean(testSuitTransformer.transformBack(testSuite));
			runReportBean.setTestSuiteId(testSuite.getId());
		});
		return runReportBean;

	}

}
