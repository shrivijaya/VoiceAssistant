package com.hcl.va.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.va.model.TestCase;

@Repository
public interface TestCaseRepository extends JpaRepository<TestCase, Integer> {

	List<TestCase> findByIsContextualFalse(Sort by);
	List<TestCase> findByIdInAndIsContextual(List<Integer> testCaseIdsList,Boolean isContextual);


}
