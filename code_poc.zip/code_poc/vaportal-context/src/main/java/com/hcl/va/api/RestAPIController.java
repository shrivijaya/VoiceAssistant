package com.hcl.va.api;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hcl.va.bean.AppResponse;
import com.hcl.va.bean.TestCasesImportResponse;
import com.hcl.va.bean.TestData;
import com.hcl.va.bean.TestExecute;
import com.hcl.va.bean.TestRunReportBean;
import com.hcl.va.bean.TestSuitRunReportBean;
import com.hcl.va.bean.TestSuiteBean;
import com.hcl.va.service.DataProcessingService;
import com.hcl.va.service.TestCaseService;
import com.hcl.va.service.TestCasesImportService;
import com.hcl.va.service.TranslateService;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api")
public class RestAPIController {

	private static final Logger log = LoggerFactory.getLogger(DataProcessingService.class);

	@Autowired
	private DataProcessingService dataProcessingService;

	//@Autowired
	//private TestRunReportRepository testRunReportRepository;


	@Autowired
	private TestCasesImportService testCasesImportService;

	@Autowired
	private TranslateService translateService;
	
	
	@Autowired
	private TestCaseService testCaseService;
	
	@GetMapping("/")
	public String welcome() {
		return "welcome to va";
	}

	@PostMapping("/uploadData")
	public AppResponse uploadFile(@RequestBody TestData testData) {

		log.info("uploadData API Request" + testData);
		AppResponse response = testCaseService.handleInputData(testData, null);
		log.info("sending response" + response);
		return response;
	}

	@GetMapping("/getTestData")
	public List<TestData> getAllData() {
		log.info("getTestData API Request");
		return testCaseService.getAllTestData();
	}

	@PostMapping("/executeTest")
	public AppResponse executeTest(@RequestBody List<TestExecute> testExecute) throws Exception {
		log.info("executeTest API Request ");
		AppResponse response = dataProcessingService.executeTestCases(testExecute);
		log.info("sending response" + response);
		return response;
	}

	@GetMapping("/getTestReport")
	public List<TestRunReportBean> getTestReport() {
		log.info("getTestReport API Request");
		return null; //testRunReportRepository.findAll();
	}

	@PostMapping("/testSuite")
	public AppResponse createTestSuite(@RequestBody TestSuiteBean testSuiteBean) throws Exception {
		log.info("testSuite API Request" + testSuiteBean);
		return testCaseService.createTestSuite(testSuiteBean);

	}

	@GetMapping("/getTestSuite")
	public List<TestData> getTestSuite(@RequestParam Integer id) {
		log.info("getTestReport API Request");
		return testCaseService.getTestSuitesTestData(id);
	}

	@GetMapping("/getTestSuiteNames")
	public List<TestSuiteBean> getTestSuite() {
		log.info("getTestReport API Request");
		return testCaseService.getTestSuites();
	}

	@GetMapping("/getTestSuiteReport")
	public List<TestRunReportBean> getTestSuiteReport(@RequestParam Integer id, @RequestParam(required =false, value="runId") Integer runId) {
		log.info("getTestSuiteReport API Request");
		return dataProcessingService.getTestSuiteReport(id,runId);
	}
	
	@GetMapping("/getTestSuiteRunReport")
	public ResponseEntity<List<TestSuitRunReportBean>> getTestSuiteRunReport(@RequestParam Integer id) {
		log.info("getTestSuiteRunReport API Request");
		return ResponseEntity.ok(dataProcessingService.getTestSuiteRunReport(id));
	}

	@PostMapping("/uploadTestCases")
	public String uploadTestCasesv1(@RequestParam("file") MultipartFile file) {
		log.info("uploadTestCases API Request");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		TestCasesImportResponse testCasesImportResponse = testCasesImportService.uploadTestCases(file);
		return gson.toJson(testCasesImportResponse);
	}
	
	@PostMapping("/executeTestSuite")
	public ResponseEntity<TestSuitRunReportBean> executeTestSuite(@RequestBody TestSuitRunReportBean suitRunReportBean) throws Exception {
		log.info("executeTestSuite API Request test suite Id = " + suitRunReportBean.getTestSuiteId());
		return ResponseEntity.ok(testCaseService.runTestSuite(suitRunReportBean));

	}
	
	@GetMapping("/translateTestCases")
	public String translateTestCases() {
		log.info("translateTestCases API Request");
		translateService.translateTestCases();
		return "Success";
	}

}
