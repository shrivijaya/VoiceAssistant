package com.hcl.va.service;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.tika.language.LanguageIdentifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.hcl.va.bean.AppResponse;
import com.hcl.va.bean.TestData;
import com.hcl.va.bean.TestRunReportBean;
import com.hcl.va.bean.TestSuitRunReportBean;
import com.hcl.va.bean.TestSuiteBean;
import com.hcl.va.exception.RecordNotFoundException;
import com.hcl.va.model.TestCase;
import com.hcl.va.model.TestSuitRunReport;
import com.hcl.va.model.TestSuite;
import com.hcl.va.repository.TestCaseRepository;
import com.hcl.va.repository.TestSuitRunReportRepository;
import com.hcl.va.repository.TestSuiteRepository;
import com.hcl.va.transformer.TestCaseTransformer;
import com.hcl.va.transformer.TestSuitTransformer;
import com.hcl.va.util.FileUtils;

@Service
public class TestCaseService {
	
	private static final Logger log = LoggerFactory.getLogger(TestCaseService.class);
	
	@Autowired
	private TestCaseRepository testCaseRepository;

	@Autowired
	private TestSuitRunReportRepository testSuitRunReportRepository;

	@Autowired
	private TestSuiteRepository testSuiteRepository;
	
	@Autowired
	private TestCaseTransformer testCaseTransformer;
	
	@Autowired
	private TestSuitTransformer testSuitTransformer;
	
	@Autowired
	private FileUploadService fileUploadService;
	
	@Autowired
	private PythonApiService pythonApiService;
	
	@Value("${imageToText.api.url}")
	private String imgToTextApiURL;
	
	@Value("${textToAudioTranslate.api.url}")
	private String txtToAudioApiURL;
	
	static String datePattern = "ddMMYYHHmmss";
	private static final  String EMPTY_STRING="";
	
	private static final FileUtils FILE_UTIL = FileUtils.INSTANCE;
	
	public AppResponse handleInputData(TestData testData , MultipartFile multipartFile) {
		TestCase inputData = testCaseTransformer.transform(testData);
		try {
			File file = null;
			if (inputData.getBase64Image() != null) {
				file = FILE_UTIL.saveImage(inputData.getBase64Image(), inputData, true);
			}
			
			MultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();

			FileSystemResource value = new FileSystemResource(file);
			map.add("file", value);
			map.add("lang", inputData.getLanguage());
			ResponseEntity<String> response = pythonApiService.getResponseFrmPythonAPI(map, imgToTextApiURL);
			if (response.getBody() != null) {
				JsonObject jobj = new Gson().fromJson(response.getBody(), JsonObject.class);
				String ouputTxt = jobj.get("message")!=null? jobj.get("message").getAsString():EMPTY_STRING;
				log.info("Image to text converted " + ouputTxt);
				if (!ouputTxt.isEmpty()) {
					inputData.setImgExtractedText(ouputTxt);
				}
				inputData.setImgUrl(fileUploadService.uploadToAWS(file));
			}

			convertTextToAudio(inputData);
		
			inputData.setCreatedOn(LocalDateTime.now());
			inputData.setLanguage(inputData.getLanguage().toLowerCase());

			TestCase parent = null;
			if (inputData.getParentId() != null) {
				parent = testCaseRepository.findById(inputData.getParentId()).get();
				inputData.setIsContextual(true);
			}
			testCaseRepository.save(inputData);
			if (parent != null) {
				parent.setChildId(inputData.getId());
				testCaseRepository.save(parent);
			}

			return buildResponse(null);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	
	public AppResponse createTestSuite(TestSuiteBean testSuiteBean) {
		TestSuite testsuite = testSuitTransformer.transform(testSuiteBean);
		List<Integer> testCaseIdsList = Arrays.asList(testSuiteBean.getTestCaseIds().split(",")).stream()
				.map(Integer::parseInt).collect(Collectors.toList());
		List<TestCase> testCaseList = testCaseRepository.findAllById(testCaseIdsList);
		if(!CollectionUtils.isEmpty(testCaseList)) {
			testCaseList.forEach(testsuite::addTestCase);
		}
		testsuite.setCreatedOn(LocalDateTime.now());
		testSuiteRepository.save(testsuite);
		return buildResponse(null);
	}
	
	public List<TestSuiteBean> getTestSuites() {
		List<TestSuiteBean> testSuitBeanList = Collections.emptyList();
		List<TestSuite> testSuiteList = testSuiteRepository.findAll();
		if (!CollectionUtils.isEmpty(testSuiteList)) {
			testSuitBeanList = testSuiteList.stream().map(testSuitTransformer::transformBack)
					.collect(Collectors.toList());
		}
		return testSuitBeanList;
	}
	
	public List<TestData> getAllTestData() {
		List<TestData> testData = Collections.emptyList();
		List<TestCase> testCaseList = testCaseRepository
				.findByIsContextualFalse(Sort.by(Sort.Direction.DESC, "createdOn"));
		if (!CollectionUtils.isEmpty(testCaseList)) {
			testData = testCaseList.stream().map(testCaseTransformer::transformBack).collect(Collectors.toList());
		}
		return testData;
	}

	public List<TestData> getTestSuitesTestData(Integer id) {
		Optional<TestSuite> suiteOp = testSuiteRepository.findById(id);
		Set<TestCase> testCaseList;
		List<TestData> testDataList = Collections.emptyList();
		if (suiteOp.isPresent()) {
			testCaseList = suiteOp.get().getTestCases();
			if (!CollectionUtils.isEmpty(testCaseList)) {
				testDataList = testCaseList.stream().filter(
						testCase -> testCase.getIsContextual() == null || !testCase.getIsContextual().booleanValue())
						.map(testcase -> testCaseTransformer.transformBack(testcase)).collect(Collectors.toList());
			}

			testDataList.stream().filter(x -> x.getChildId() != null).forEach(x -> {
				x.setChildData(testCaseTransformer.transformBack(testCaseRepository.findById(x.getChildId()).get()));
			});
		}

		return testDataList;
	}
	
	public TestSuitRunReportBean runTestSuite(TestSuitRunReportBean testSuitRunReportBean) {
		Integer testSuiteId = testSuitRunReportBean.getTestSuiteId();
		Optional<TestSuite> testSuiteOp = testSuiteRepository.findById(testSuiteId);
		if(testSuiteOp.isPresent()) {
			TestSuitRunReport suitRunReport = new TestSuitRunReport();
			suitRunReport.setTestSuite(testSuiteOp.get());
			suitRunReport.setCreatedOn(LocalDateTime.now());
			testSuitRunReportRepository.save(suitRunReport);
			testSuitRunReportBean.setId(suitRunReport.getId());
			testSuitRunReportBean.setCreatedOn(suitRunReport.getCreatedOn());
		}else {
			throw new RecordNotFoundException("Invalid testSuiteId = "+testSuiteId);
		}
		return testSuitRunReportBean;
	}
	
	private void convertTextToAudio(TestCase inputData) throws Exception {

		MultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();
		LanguageIdentifier identifier = new LanguageIdentifier(inputData.getInputText());
		map.add("lang_tgt", inputData.getLanguage());
		map.add("lang_src", identifier.getLanguage());
		map.add("txt", inputData.getInputText());
		ResponseEntity<String> response = pythonApiService.getResponseFrmPythonAPI(map, txtToAudioApiURL);

		if (response.getBody() != null) {
			JsonObject jobj = new Gson().fromJson(response.getBody(), JsonObject.class);
			inputData.setInputAudioUrl(jobj.get("message")!=null? jobj.get("message").getAsString():EMPTY_STRING);

		}
		map.remove("txt");
		map.add("txt", inputData.getExpectedOutputText());
		ResponseEntity<String> expectedRes = pythonApiService.getResponseFrmPythonAPI(map, txtToAudioApiURL);

		if (expectedRes.getBody() != null) {
			JsonObject expJobj = new Gson().fromJson(expectedRes.getBody(), JsonObject.class);
			inputData.setExpectedOutputText(expJobj.get("message")!=null? expJobj.get("message").getAsString():EMPTY_STRING);

		}

	}

	private AppResponse buildResponse(TestRunReportBean report) {
		AppResponse appResponse = new AppResponse("200", "Success");
		if (report != null) {
			appResponse.setScore(String.valueOf(report.getScore()));
			appResponse.setResult(report.getResult());
		}

		return appResponse;
	}

}
