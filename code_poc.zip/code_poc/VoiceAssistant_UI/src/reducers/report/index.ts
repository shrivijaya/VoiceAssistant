import { ReportList } from '../../models/Report'
import { FetchReports } from "../../actions/report";

export interface AppState {
    reportList: ReportList[];
}

const defaultState = {
    reportList: [],
}

export const ReportReducer = (state: AppState = defaultState, action: FetchReports) => {
    switch(action.type) {
        case 'FETCH_REPORTS':
            return {
                ...state,
                reportList: action.reportList //resolvePromise(action)
            };
 
        default:
            return state
    }
}
