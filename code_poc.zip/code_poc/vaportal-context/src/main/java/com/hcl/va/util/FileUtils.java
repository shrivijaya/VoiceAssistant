package com.hcl.va.util;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.hcl.va.model.TestCase;

public enum FileUtils {
	INSTANCE;
	
	private static final String DATE_PATTERN = "ddMMYYHHmmss";
	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern(DATE_PATTERN);
	
	private static final Logger log = LoggerFactory.getLogger(FileUtils.class);
	
	public File saveImage(String imageBase64, TestCase testData, Boolean isImage) {
		String fileName = null;

		try {
			byte[] imageByteArray = null;
			if (isImage) {
				fileName = LocalDateTime.now().format(FORMATTER) + ".png";
				imageByteArray = decodeImage(imageBase64.replaceAll("data:image/png;base64,", ""));

			} else {
				fileName = LocalDateTime.now().format(FORMATTER) + ".wav";
				imageByteArray = decodeImage(imageBase64.replaceAll("data:audio/wav;base64,", ""));
			}

			FileOutputStream imageOutFile = new FileOutputStream(fileName);

			imageOutFile.write(imageByteArray);
			imageOutFile.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new File(fileName);

	}
	
	public File callFfmpeg(File f, String fileName) throws Exception {
		Process p = null;
		try {
			Long startTime = System.currentTimeMillis();
			log.info("calling ffmpeg " + f.getAbsolutePath() + " saved file " + fileName);
			//C:\\Users\\shailendra.kum\\Downloads\\setup\\ffmpeg-20200216-8578433-win64-static\\bin\\
			
			String cmd = "/usr/local/bin/ffmpeg -i " + f.getAbsolutePath() + " " + fileName;
			log.info("cmd==="+cmd);
			
			
			p = Runtime.getRuntime().exec(cmd);
			p.waitFor(10, TimeUnit.SECONDS);
			log.info("conversion done");
			p.destroyForcibly();
			log.info("time taken by ffmpeg "
					+ (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTime)));
			return new File(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			p.destroyForcibly();
		}
	}
	
	public  File getFile(MultipartFile multipartFile) {
		try {
			File file = new File(multipartFile.getOriginalFilename());
			file.createNewFile();
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(multipartFile.getBytes());
			fos.close();
			return file;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static byte[] decodeImage(String imageDataString) {
		return Base64.decodeBase64(imageDataString);
	}

}
