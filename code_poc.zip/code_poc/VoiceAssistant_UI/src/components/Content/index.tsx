import React from 'react';
import { Category } from '../Category';
import { Execution } from '../Execution';
import { Navigation } from '../Navigation';
import { Reports } from '../Reports';

import { HashRouter as Router, Switch, Route } from "react-router-dom";
export class Content extends React.Component {
   render() {
      return (
         // <section className="content">
         //    <div>
               <div className="container">
                  <Router >
                     <Switch>
                        <Route exact path="/">
                           <Category />
                        </Route>
                        <Route exact path="/execution">
                           <Execution />
                        </Route>
                        <Route  path="/reports">
                           <Reports />
                        </Route>
                     </Switch>
                  </Router>
               </div>
         //    </div>
         // </section>
      );
   }
}
