package com.hcl.va.transformer;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.hcl.va.bean.TestData;
import com.hcl.va.model.TestCase;

@Component
public class TestCaseTransformer {
	
	public TestCase transform(TestData testData) {
		TestCase testCase = new TestCase();
		BeanUtils.copyProperties(testData, testCase,"expectedOutputText","imgExtractedText" );
		testCase.setExpectedOutputText(testData.getExpectedOutput());
		testCase.setImgExtractedText(testData.getImgToText());
		return testCase;
		
	}
	
	public TestData transformBack(TestCase testcase) {
		TestData testData = new TestData();
		BeanUtils.copyProperties(testcase, testData,"expectedOutput","imgToText" );
		testData.setExpectedOutput(testcase.getExpectedOutputText());
		testData.setImgToText(testcase.getImgExtractedText());
		testData.setCreatedDate(testcase.getCreatedOn());
		return testData;
		
	}

}
