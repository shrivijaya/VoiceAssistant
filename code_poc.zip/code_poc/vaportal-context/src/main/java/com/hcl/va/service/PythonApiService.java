package com.hcl.va.service;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Service
public class PythonApiService {
	
	private static final Logger log = LoggerFactory.getLogger(PythonApiService.class);

	public ResponseEntity<String> getResponseFrmPythonAPI(MultiValueMap<String, Object> map, String url)
			throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		try {
			Long startTime = System.currentTimeMillis();
			log.info("calling python API " + url);
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<MultiValueMap<String, Object>>(map,
					headers);
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, request, String.class);
			log.info("response from API " + response);
			log.info("time taken by python api "
					+ (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTime)));
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("python api exception");
			throw e;
		}
	
	}

}
