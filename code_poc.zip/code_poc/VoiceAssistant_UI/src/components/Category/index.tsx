import * as React from 'react';
import { CategoryForm } from '../CategoryForm';

export class Category extends React.Component {
    render() {
        return (
            <>     
                <CategoryForm />
            </>
        )
    }
}