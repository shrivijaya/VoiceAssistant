import React from 'react';

export class Camera extends React.Component<{}, {}> {
   video: any;
   canvas: any;
   webcamStream: any;
   ctx: any;
   constructor(prop) {
      super(prop);
      this.startWebcam = this.startWebcam.bind(this);
      this.stopWebcam = this.stopWebcam.bind(this);
      this.snapshot = this.snapshot.bind(this);
      this.snapshot = this.snapshot.bind(this);
      
   }

   startWebcam() {
      navigator.mediaDevices.getUserMedia({ video: true, audio: false })
         .then((stream) => {
            this.video = document.querySelector('video');
            this.video.srcObject = stream;
            this.webcamStream = stream;
            this.video.play();
         })
         .catch((err) => {
            console.log("An error occurred: " + err);
         });
   }
   stopWebcam() {
      if (this.webcamStream != null) {
         this.webcamStream.getTracks().map(function (val) {
            val.stop();
         });
      }

   }
   init() {
      this.canvas = document.getElementById("myCanvas");
      this.ctx = this.canvas.getContext('2d');
   }
   snapshot() {
      // Draws current image from the video element into the canvas

      this.ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
      var imageData = this.canvas.toDataURL("image/png");
   }
   componentDidMount() {
      this.init();
   }
   componentDidUpdate() {

   }

   render() {

      return (
         <div>
            <p>
               <button onClick={this.startWebcam}>Start WebCam</button>
               <button onClick={this.stopWebcam}>Stop WebCam</button>
               <button onClick={this.snapshot}>Take Snapshot</button>
            </p>
            <video
               onClick={this.snapshot.bind(this)}
               width={400}
               height={400}
               id="video"
               controls
               autoPlay
            />
            <p>Screenshots : </p>
            <p>
               <canvas id="myCanvas" width={400} height={350} />
            </p>
         </div>
      );
   }
}
