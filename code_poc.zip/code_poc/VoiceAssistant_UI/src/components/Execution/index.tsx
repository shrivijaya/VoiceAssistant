import React from 'react';
import { Timer } from '../Element/Timer';
import CheckBox from '../Element/CheckBox';
import ExeMsg from '../../static/conf/executionMessages.json';
import { ExecutionService } from '../../services/ExecutionService';
import { MediaService } from '../../services/MediaService';
import { ExecutionStatus } from '../ExecutionStatus';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { NotifyService } from '../../services/NotifyService';
import './index.css';

interface State {
   message: string,
   status: number,
   seconds: any,
   value: any,
   showTimer: boolean,
   testCases: any,
   executionStart: boolean,
   selectedTestCases: any,
   enbleVideo: boolean;
   loaderCreateSuite: boolean;
   testSuiteName: string;
   suiteNames: any;
   uploadLoader: boolean;
   executionTableLoader: boolean;
   testCasesLoader: boolean;
}
const API_URL = process.env.REACT_APP_API_SERVER_NAME + ':' + process.env.REACT_APP_API_SERVER_HOST + '/api';
export class Execution extends React.Component<{}, State> {
   video: any;
   canvas: any;
   webcamStream: any;
   ctx: any;
   speakRecognation: MediaService;
   synth: any;
   runningTestCase: string;
   voiceInput: string;
   executionService: ExecutionService;
   selectedTestCases: any;
   selectedTestCasesForSuite: any;
   notify: NotifyService;
   uploadFile: string
   selectedSuiteId: number

   constructor(prop) {
      super(prop);
      this.execute.bind(this);
      this.speakRecognation = new MediaService(this);
      this.synth = this.speakRecognation.getSynthObj();
      this.executionService = new ExecutionService();
      this.selectedTestCases = [];
      this.selectedTestCasesForSuite = [];
      this.notify = new NotifyService();
      this.handleSelectSuite = this.handleSelectSuite.bind(this);
   }
   state: State = {
      message: "Click Execute to Start",
      status: 0,
      seconds: 0,
      value: 0,
      showTimer: false,
      testCases: [],
      executionStart: false,
      selectedTestCases: [],
      enbleVideo: false,
      loaderCreateSuite: false,
      testSuiteName: "",
      suiteNames: [],
      uploadLoader: false,
      executionTableLoader: false,
      testCasesLoader: true
   }
   changeTestSuiteName = (event) => {
      this.setState({ testSuiteName: event.target.value })
   }
   delay = sec => new Promise(resolve => setTimeout(resolve, Timer.getSecToMS(sec)));
   
   execute = async () => {
      this.setState({ executionStart: true });
      let waitTime: any = {
         audio: 7,
         image: 4
      };
      let runId=0;
      console.log(this.state.selectedTestCases)
      for (let i = 0; i < this.state.selectedTestCases.length; i++) {
         this.changeExectionStatus(i, "In-Execution");
         try {
            if (this.state.selectedTestCases[i].childData) {
               let mediaResponse: any = await this.runParentTestCase(this.state.selectedTestCases[i], { audio: 5, image: 4 }, true);
               let childMediaResponse: any = await this.runTestCase(this.state.selectedTestCases[i].childData, waitTime, false);
               childMediaResponse.childTestCaseId = this.state.selectedTestCases[i].childId;
               this.setState({ message: ExeMsg[4].message, status: ExeMsg[4].messageCode });
               let executionRs: any = await this.executionService.executeTestUpload({ runId:runId,testCaseId: this.state.selectedTestCases[i].id, testSuiteId: this.selectedSuiteId, mediaResponse, childMediaResponse });
               this.changeExectionStatus(i, executionRs.data.result ? executionRs.data.result : executionRs.data.responseMessage);
            } else {
               let mediaResponse: any = await this.runTestCase(this.state.selectedTestCases[i], waitTime, true);
               this.setState({ message: ExeMsg[4].message, status: ExeMsg[4].messageCode });
               let executionRs: any = await this.executionService.executeTestUpload({ runId:runId,testCaseId: this.state.selectedTestCases[i].id, testSuiteId: this.selectedSuiteId, mediaResponse });
               runId = executionRs.data.runId;
               this.changeExectionStatus(i, executionRs.data.result ? executionRs.data.result : executionRs.data.responseMessage);
            }
         } catch (error) {
            console.error(error);
            this.changeExectionStatus(i, "Processing Failed");
         }
         this.setState({ message: ExeMsg[5].message, status: ExeMsg[5].messageCode });
         await this.delay(1);
         this.setState({ message: ExeMsg[6].message, status: ExeMsg[6].messageCode });
         if (i == (this.state.selectedTestCases.length) - 1)
            this.setState({ executionStart: false });
      }
   }

   runParentTestCase = async (testcase: any, waitTime: any, isparent = true) => {
      console.log("parent")
      let _self = this;
      _self.setState({ enbleVideo: true });
      let speakRecognation = _self.speakRecognation;
      let synth = _self.synth;
      let delay = _self.delay;
      _self.runningTestCase = testcase.inputText;
      _self.setState({ message: ExeMsg[0].message, status: ExeMsg[0].messageCode });
      if (isparent) {
         await delay(1);
      }
      return new Promise(async (resolve, reject) => {

         _self.setState({ message: ExeMsg[1].message, status: ExeMsg[1].messageCode });

         let camraData: any = await speakRecognation.startCamra(_self);

         if (testcase.inputAudioURL) {
            await speakRecognation.playCommand(testcase.inputAudioURL);//"http://localhost:3000/mp3file.mp3"
         } else {
            if (isparent) {
               await speakRecognation.getTextToVoice(synth, "Hey Portal");
            }
            await speakRecognation.getTextToVoice(synth, _self.runningTestCase);
         }

         /*Start Audio recording Process*/
         _self.setState({ message: ExeMsg[2].message, status: ExeMsg[2].messageCode });
         let audioData: any = await speakRecognation.startAudioRecording(_self, waitTime.audio);
         // speakRecognation.downloadFileFromBlob(audioData.audioFileData,testcase.id+'_filename.mp3');

         /*Start Image Snapshot Process*/

         _self.setState({ message: ExeMsg[3].message, status: ExeMsg[3].messageCode });
         let imageData: any = await speakRecognation.captureImage(_self);
         //  speakRecognation.downloadFileFromBlob(imageData.imageBlobData,testcase.id+'_filename.png');

         resolve({ audioData, imageData });
      });
   }
   runTestCase = async (testcase: any, waitTime: any, isparent = true) => {
      console.log("test case run")
      console.log(testcase)
      let _self = this;
      let speakRecognation = _self.speakRecognation;
      let synth = _self.synth;
      let delay = _self.delay;
      _self.runningTestCase = testcase.inputText;
      _self.setState({ message: ExeMsg[0].message, status: ExeMsg[0].messageCode });
      if (isparent) {
         await delay(1);
      }
      return new Promise(async (resolve, reject) => {
         _self.setState({ message: ExeMsg[1].message, status: ExeMsg[1].messageCode });
   console.log(testcase)
         if (testcase.inputAudioURL) {
            await speakRecognation.playCommand(testcase.inputAudioURL);//"http://localhost:3000/mp3file.mp3"
         } else {
            if (isparent) {
               await speakRecognation.getTextToVoice(synth, "Hey Siri");
            }
            await speakRecognation.getTextToVoice(synth, _self.runningTestCase);
         }

         /*Start Audio recording Process*/
         _self.setState({ message: ExeMsg[2].message, status: ExeMsg[2].messageCode });
         let audioData: any = await speakRecognation.startAudioRecording(_self, waitTime.audio);
         // speakRecognation.downloadFileFromBlob(audioData.audioFileData,testcase.id+'_filename.mp3');

         /*Start Image Snapshot Process*/
         _self.setState({ enbleVideo: true });
         _self.setState({ message: ExeMsg[3].message, status: ExeMsg[3].messageCode });
         let imageData: any = await speakRecognation.getVideoSnapshot(_self, waitTime.image);
         //  speakRecognation.downloadFileFromBlob(imageData.imageBlobData,testcase.id+'_filename.png');

         resolve({ audioData, imageData });
      });
   }
   componentDidMount() {
      this.executionService.getTestData(this);
      this.executionService.getTestSuiteData(this);
   }
   changeExectionStatus = (index, status, ) => {
      var items = [...this.state.selectedTestCases];
      items[index].executionStatus = status;
      this.setState({ selectedTestCases: items });
   }
   handleSelectSuite = async (event) => {
      this.selectedSuiteId = parseInt(event.target.value);
      this.setState({ executionTableLoader: true });

      if (event.target.value) {
         try {
            let response: any = await this.executionService.getSelectedTestSuiteData(event.target.value);
            (response.data).forEach(el => {
               el.isChecked = false;
               el.value = el.testCaseName ? el.testCaseName : 'Test';
               el.executionStatus = "In-Queue";
            });
            this.setState({ selectedTestCases: response.data });
            this.setState({ executionTableLoader: false });
         } catch (error) {
            console.log(error);
            this.setState({ selectedTestCases: [] });
            this.setState({ executionTableLoader: false });
         }
      } else {
         this.setState({ selectedTestCases: [] });
         this.setState({ executionTableLoader: false });
      }
   }
   handleUploadFileChange = (event) => {
      this.setState({ uploadLoader: true })
      this.uploadFile = event.target.files[0].name;

      let formData = new FormData();
      formData.append('file', event.target.files[0])

      this.executionService.uploadTestCases(formData)
         .then((response) => {
            response.data.testDataList.forEach(el => {
               el.value = el.testCaseName ? el.testCaseName : '';
            });
            this.setState({ testCases: response.data.testDataList });
            this.notify.notifyMessage('Test Case Imported', response.status);
            this.selectedTestCasesForSuite = this.state.testCases.filter(e => e.isChecked);
         }).catch(() => {
            this.notify.notifyMessage("Internal server error", 500)
         }).finally(() => {
            this.setState({ uploadLoader: false })
            this.uploadFile = ""
         })
   }
   handleSubmit = (event) => {
      event.preventDefault()
      this.setState({ loaderCreateSuite: true });
      let selectedTestCasesIds: any = [];

      this.selectedTestCasesForSuite.map((selectedTestCasesObject) => {
         selectedTestCasesIds.push(selectedTestCasesObject.id);
         if (selectedTestCasesObject.childId != null) {
            selectedTestCasesIds.push(selectedTestCasesObject.childId);
         }
      });

      let data = JSON.stringify({
         "suiteName": this.state.testSuiteName,
         "testCaseIds": selectedTestCasesIds.join(',')
      });

      this.executionService.createTestSuite(data)
         .then((response: any) => {
            this.notify.notifyMessage(response.data.responseMessage, response.status)
            this.setState({ testSuiteName: "" });
            this.executionService.getTestSuiteData(this);
         }).catch(() => {
            this.notify.notifyMessage("Internal server error", 500)
         }).finally(() => {
            this.setState({ loaderCreateSuite: false });
         })
   }

   handleAllChecked = (event) => {
      let testCases = this.state.testCases
      testCases.forEach(testCase => {
         testCase.isChecked = event.target.checked;
         testCase.executionStatus = "In-Queue";
      });
      this.setState({ testCases: testCases });
      this.selectedTestCasesForSuite = this.state.testCases.filter(e => e.isChecked);
   }

   handleCheckChieldElement = (event) => {
      let testCases = this.state.testCases;
      testCases.forEach(testCase => {
         if (testCase.id === +event.target.value) {
            testCase.isChecked = event.target.checked;
            testCase.executionStatus = "In-Queue";
         }
      });
      this.setState({ testCases: testCases });
      this.selectedTestCasesForSuite = this.state.testCases.filter(e => e.isChecked);
   }

   render() {
      let VideoEl = <video
         width={400}
         height={300}
         ref="video"
      />
      let CanvasEl = <canvas ref="canvas" width={0} height={0} />
      if (this.state.status > 4 && !this.state.enbleVideo) {
         VideoEl = null;
      }

      return (
         <>
            <div className="main">
           
               <div className="row">
                  <div className={`${this.runningTestCase ? 'col-md-7' : 'col-md-12'} tables`}>
                     <div className="table-exexution table-exicution-width">  <b>Execute Test Case</b><br/>  <br/>  
                        <div className="row">
                           <div className="col-md-12">
                              {this.state.status < 0 &&
                                 <div className="alert alert-danger" role="alert" >{this.state.message} </div>
                              }
                           </div>
                        </div>
                        <div className="row padding">
                           <div className="col-md-9">
                              <input type="text" className="form-control" value={this.uploadFile} placeholder="CSV file" />
                           </div>
                           <div className="col-md-3">
                              {
                                 this.state.uploadLoader
                                    ?
                                    <div className="loader">Loading...</div>
                                    :
                                    <label className="btn-execute btn btn-info text-center">
                                       <FontAwesomeIcon icon="file-import" /> Import <input onChange={this.handleUploadFileChange.bind(this)} hidden type="file" />
                                    </label>
                              }
                           </div>
                        </div>
                        <form method="post" onSubmit={this.handleSubmit}>
                           <div className="row">
                              <div className="col-md-12">
                                 <table className="table exexution-table">
                                    <thead>
                                       <tr>
                                          <th><input type="checkbox" onClick={this.handleAllChecked} value="checkedall" /> &nbsp; Select All</th>
                                          <th>ID</th>
                                          <th>Test Case</th>
                                          <th>Language</th>
                                       </tr>
                                    </thead>
                                    <tbody>
                                       {this.state.testCasesLoader ?
                                          <tr><td><div className="loader"></div></td></tr>
                                          : this.state.testCases.length > 0 ?
                                             this.state.testCases.map((tc) => {
                                                return (<tr key={`t${tc.id}`}>
                                                   <td><CheckBox handleCheckChieldElement={this.handleCheckChieldElement}  {...tc} /></td>
                                                   <td>{tc.id}</td>
                                                   <td>{tc.value}</td>
                                                   <td>{tc.language}</td>
                                                </tr>)
                                             })
                                             :
                                             <tr><td><h6>No test case available</h6></td></tr>
                                       }
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <div className="row">
                              <div className="col-md-9">
                                 <input type="text" onChange={this.changeTestSuiteName.bind(this)} name="suiteName" value={this.state.testSuiteName} placeholder="Test suite name" className="form-control" required />
                              </div>
                              <div className="col-md-3">
                                 {this.state.loaderCreateSuite ?
                                    <div className="loader">Loading...</div>
                                    :
                                    <button type="submit" disabled={false} className="btn btn-info  btn-execute">Create suite</button>
                                 }
                              </div>
                           </div>
                        </form>
                        {this.state.status > 0 &&
                           <div className="row snapshot">
                              <div className="col-md-12 text-center">
                                 {this.state.showTimer &&
                                    <div className="timer">
                                       <Timer value={this.state.value} seconds={this.state.seconds} />
                                    </div>
                                 }
                                 <div className="spacer"></div>
                                 {this.state.enbleVideo ?
                                    VideoEl
                                    :
                                    CanvasEl
                                 }
                              </div>
                           </div>
                        }
                     </div>
                     <div className="spacer"></div>
                     <div className="table-exexution">
                        <div className="row">
                           <div className="col">
                              <select className="form-control" onChange={this.handleSelectSuite}>
                                 <option value="">Select test suite</option>
                                 {
                                    this.state.suiteNames.map((tc) => {
                                       return (<option key={tc.id} value={tc.id}>{tc.suiteName}</option>)
                                    })
                                 }
                              </select>
                           </div>
                        </div>
                        <div className="row">
                           <div className="col-md-12">
                              <table className="table table2">
                                 <thead>
                                    <tr>
                                       <th>ID</th>
                                       <th>Test Case</th>
                                       <th>Status</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    {this.state.executionTableLoader ?
                                       <tr><td><div className="loader">Loading...</div></td></tr>
                                       :
                                       this.state.selectedTestCases.length > 0 ?
                                          this.state.selectedTestCases.map((tc) => {
                                             return (<tr key={`p ${tc.id}`}>
                                                <td>{tc.id}</td>
                                                <td>{tc.value}</td>
                                                <td>{tc.executionStatus}</td>
                                             </tr>)
                                          })
                                          :
                                          <tr><td><h6>No test case selected for execution</h6></td></tr>
                                    }
                                 </tbody>
                              </table>
                           </div>
                        </div>
                        <div className="row">
                           <div className="col-md-12 text-center">
                              {this.state.selectedTestCases.length > 0 ?
                                 this.state.executionStart ?
                                    <div className="loader">Loading...</div>
                                    :
                                    <button className="btn btn-info  btn-execute" onClick={this.execute.bind(this)}>Execute</button>
                                 : ''
                              }
                           </div>
                        </div>
                     </div>
                  </div>
                  <ExecutionStatus runningTestCase={this.runningTestCase} status={this.state.status} />
               </div>
            </div>
         </>
      );
   }
}
