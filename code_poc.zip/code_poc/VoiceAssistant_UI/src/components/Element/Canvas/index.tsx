import React from 'react';

let Canvas = function statelessFunctionComponentClass(props) {
  return (
   <canvas ref={props.canvas } width={0} height={0} />
  );
};

export default Canvas;