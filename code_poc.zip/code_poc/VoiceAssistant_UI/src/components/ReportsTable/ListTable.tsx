/* eslint-disable jsx-a11y/anchor-is-valid */
import * as React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { ReportsTable } from './index'

interface Props {
    selected: number,
    loader: boolean,
    reportsBySuitId: Array<any>
}

interface State {
    isShow: boolean
    testCaseById: Array<any>
}

export class ReportListTable extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.viewSingleTestCase = this.viewSingleTestCase.bind(this)
    }
    state: State = {
        isShow: false,
        testCaseById: []
    }

    viewSingleTestCase = (id) => {
        this.setState({isShow: true})
        this.setState(
            {testCaseById: this.props.reportsBySuitId.find((testSuit) => testSuit.id === id)}
        )
    }

    render() {
        const renderTableData = this.props.reportsBySuitId.map((object, index) => {
            return (
             <>
                <div className="row" key={object.id}>
                    <div className="form-group col-md-2  test-case-result-name">
                        <label>{index + 1}</label>
                    </div>
                    <div className="form-group col-md-8  test-case-result-name">
                        <label>{object.testCaseName}</label>
                    </div>
                    <div className="form-group col-md-1  test-case-result-name">
                    <label  className={object.result === 'FAIL' ? 'alert-red' : 'alert-green'} >{object.result}</label>
                    </div>
                    
                    <div className="icon form-group col-md-1  test-case-result-name">
                        <a className="button-view" onClick={this.viewSingleTestCase.bind(this, object.id)}><FontAwesomeIcon icon="eye" color="#028AA4"/></a>
                    </div>
                </div>
             </>
            )
        }) 

        return (
            <>
                <div className={ `${this.state.isShow ? 'col-md-6 case-batch' : 'col-md-12' }`}>
                    <div className="report-table">
                        
                        <div className="row">
                            <div className="form-group col-md-12 test-cases">
                                <label>Test Status</label>
                            </div>
                            <div className="form-group col-md-2  heading-case-name">
                            <label>S.No.</label>
                            </div>
                            <div className="form-group col-md-8  heading-case-name">
                            <label>Test Case</label>
                            </div>
                            <div className="form-group col-md-2  heading-case-name tex">
                                <label>Status</label>
                            </div>
                        </div>
                        {this.props.loader 
                        ? <div className="loader col-md-12 text-center">Loading...</div>
                        :  renderTableData
                        }
                    </div>
                </div>
                {this.state.isShow ? (
                    <ReportsTable
                    reports={this.state.testCaseById}
                    />
                ) : null}
            </>
        )
    }
}