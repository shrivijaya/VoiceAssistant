export interface CategoryModel {
    text_case: string
    command: string
    responses?: any
    image?: File
    selected: string
    loader: boolean
    fileName?:string
    enbleVideo:boolean
    cimage:string
    showModal:boolean
    parentTestCases:any
    parentLoader:boolean
    selectedParent:any
}

export const languagesList = {
    languages:[
        {id: 1, name: "EN" ,text:"English (US)",isEnabled:false},
        {id: 11, name: "IT" ,text:"Italian (IT)",isEnabled:false},
        {id: 13, name: "BR" ,text:"Portuguese (BR)",isEnabled:false},
        {id: 9, name: "FR" ,text:"French (CA)",isEnabled:false},
        {id: 2, name: "ES" ,text:"Spanish (US)",isEnabled:true},
        {id: 3, name: "DE" ,text:"German (DE)",isEnabled:true},
        {id: 4, name: "AU" ,text:"English (AU)",isEnabled:true},
        {id: 5, name: "CA" ,text:"English (CA)",isEnabled:true},
        {id: 6, name: "IN" ,text:"English (IN)",isEnabled:true},
        {id: 7, name: "UK" ,text:"English (UK)",isEnabled:true},
        {id: 8, name: "FR" ,text:"French (FR)",isEnabled:true},
        {id: 10, name: "IN" ,text:"Hindi (IN)",isEnabled:true},
        {id: 12, name: "JP" ,text:"Japanese (JP)",isEnabled:true},
        {id: 14, name: "MX" ,text:"Spanish (MX)",isEnabled:true},
        {id: 15, name: "ES" ,text:"Spanish (ES)",isEnabled:true},

    ]
}