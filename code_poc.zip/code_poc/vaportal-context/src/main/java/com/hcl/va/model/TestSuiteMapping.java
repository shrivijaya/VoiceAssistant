package com.hcl.va.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the test_suite_mapping database table.
 * 
 */
@Entity
@Table(name="test_suite_mapping")
@NamedQuery(name="TestSuiteMapping.findAll", query="SELECT t FROM TestSuiteMapping t")
public class TestSuiteMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TestSuiteMappingPK id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_ON")
	private Date createdOn;

	//bi-directional many-to-one association to TestCase
	@ManyToOne
	@JoinColumn(name="CASE_ID",insertable=false,updatable=false)
	private TestCase testCase;

	//bi-directional many-to-one association to TestSuite
	@ManyToOne
	@JoinColumn(name="SUIT_ID",insertable=false,updatable=false)
	private TestSuite testSuite;

	public TestSuiteMapping() {
	}

	public TestSuiteMappingPK getId() {
		return this.id;
	}

	public void setId(TestSuiteMappingPK id) {
		this.id = id;
	}

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public TestCase getTestCase() {
		return this.testCase;
	}

	public void setTestCase(TestCase testCase) {
		this.testCase = testCase;
	}

	public TestSuite getTestSuite() {
		return this.testSuite;
	}

	public void setTestSuite(TestSuite testSuite) {
		this.testSuite = testSuite;
	}

}