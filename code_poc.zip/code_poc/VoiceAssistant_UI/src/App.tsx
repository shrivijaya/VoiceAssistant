import React from 'react';
import { Container } from './components';
import logo from './logo.svg';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'
const App: React.FC = () => {
  return (
    <div className="App">
      <Container />
    </div>
  );
}

export default App;
