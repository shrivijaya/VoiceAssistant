import React from 'react';
import { Link } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import ExeMsg from '../../static/conf/executionMessages.json';
import './index.css'
const CONF ={
   EXCLUDE_MSG:7
}
export class ExecutionStatus extends React.Component<{ runningTestCase, status }, {}> {
   constructor(prop) {
      super(prop);
   }
   render() {
      return (
         <>
            {this.props.runningTestCase &&
               <div className="col-md-5 tab-execution">
                  <div className="chart-data">
                     <div className="row">
                        <div className="col-md-12">
                           <p className="text-center running-test-case"><b>{this.props.runningTestCase}?</b></p>
                        </div>
                        <div className="col-md-12">
                           <p className="text-center"><FontAwesomeIcon icon="arrow-down" /></p>
                        </div>
                     </div>
                     {
                        ExeMsg.map((exeMsg) => {
                           return (
                              <span key={exeMsg.messageCode}>
                                 {exeMsg.messageCode < CONF.EXCLUDE_MSG  &&
                                    <div className="row" >
                                       <div className="col-md-12">
                                          {this.props.status === exeMsg.messageCode ?
                                             <p className="text-center"><b>{exeMsg.message}</b></p>
                                             :
                                             <p className="text-center">{exeMsg.message}</p>
                                          }
                                       </div>
                                       <div className="col-md-12">
                                          <p className="text-center"><FontAwesomeIcon icon="arrow-down" /></p>
                                       </div>
                                    </div>}</span>)
                        })
                     }
                     <div className="row">
                        <div className="col-md-12 text-center">
                           <Link to='/reports'>
                              <button className={`btn btn-outline-light ${this.props.status === CONF.EXCLUDE_MSG ? 'button-report-selected' : 'button-report'}`}>VIEW REPORT</button>
                           </Link>
                        </div>
                     </div>
                  </div>
               </div>
            }
         </>
      );
   }
}
