package com.hcl.va.bean;

import java.time.LocalDateTime;

public class TestSuiteBean {
	

		private String suiteName;

		private Integer id;

		private String testCaseIds;

		private LocalDateTime createdDate;

		public LocalDateTime getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(LocalDateTime createdDate) {
			this.createdDate = createdDate;
		}

		public String getSuiteName() {
			return suiteName;
		}

		public void setSuiteName(String suiteName) {
			this.suiteName = suiteName;
		}

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getTestCaseIds() {
			return testCaseIds;
		}

		public void setTestCaseIds(String testCaseIds) {
			this.testCaseIds = testCaseIds;
		}

}
