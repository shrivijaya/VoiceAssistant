/* eslint-disable jsx-a11y/anchor-is-valid */
import * as React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { ReportsTable } from '../ReportsTable';

interface Props {
    selected: number,
    loader: boolean,
    reportsBySuitId: Array<any>
}

interface State {
    isShow: boolean
    testCaseById: Array<any>
}

export class ReportListTable extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.viewSingleTestCase = this.viewSingleTestCase.bind(this)
    }
    state: State = {
        isShow: false,
        testCaseById: []
    }

    viewSingleTestCase = (id) => {
        this.setState({isShow: true})
        this.setState(
            {testCaseById: this.props.reportsBySuitId.find((testSuit) => testSuit.id === id)}
        )
    }
    componentWillReceiveProps() {
        this.setState({isShow: false})
    }
    render() {
        const renderTableData = this.props.reportsBySuitId.map((object, index) => {
            return (
                <div className="row" key={object.id}>
                    <div className="col-md-2  test-case-result-name">
                        <label>{object.id}</label>
                    </div>
                    <div className="col-md-8  test-case-result-name">
                        <label>{object.testCaseName}</label>
                    </div>
                    <div className="col-md-1  test-case-result-name">
                    <label  className={object.score < 0.5 ? 'alert-red' : 'alert-green'} >{object.score < 0.5 ? 'FAIL': 'PASS'}</label>
                    </div>
                    
                    <div className="icon col-md-1  test-case-result-name">
                        <a className="button-view" onClick={this.viewSingleTestCase.bind(this, object.id)}><FontAwesomeIcon icon="eye" color="#028AA4"/></a>
                    </div>
                </div>
            )
        }) 

        return (
            <>
                <div className={ `${this.state.isShow ? 'col-md-6 case-batch' : 'col-md-12' }`}>
                    <div className="report-table">
                        <div className="row">
                            <div className="col-md-12 test-cases">
                                <label>Test Status</label>
                            </div>
                            <div className="col-md-2  heading-case-name">
                            <label>ID</label>
                            </div>
                            <div className="col-md-8  heading-case-name">
                            <label>Test Case</label>
                            </div>
                            <div className="col-md-2  heading-case-name tex">
                                <label>Status</label>
                            </div>
                        </div>
                        {this.props.loader 
                        ? <div className="loader col-md-12 text-center">Loading...</div>
                        :  this.props.reportsBySuitId.length>0?
                             renderTableData
                             :
                             <div className="row" >
                                 <div className="col text-center">No Record Available</div>
                              </div>
                        }
                    </div>
                </div>
                {(this.state.isShow && this.props.reportsBySuitId) ? (
                    <ReportsTable
                    reports={this.state.testCaseById}
                    />
                ) : null}
            </>
        )
    }
}