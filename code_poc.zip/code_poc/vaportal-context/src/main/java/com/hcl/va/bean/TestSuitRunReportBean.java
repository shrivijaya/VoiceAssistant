package com.hcl.va.bean;

import java.time.LocalDateTime;

public class TestSuitRunReportBean {
	
	private Integer id;
	
	private LocalDateTime createdOn;
	
	private TestSuiteBean testSuiteBean;
	
	private Integer testSuiteId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public TestSuiteBean getTestSuiteBean() {
		return testSuiteBean;
	}

	public void setTestSuiteBean(TestSuiteBean testSuiteBean) {
		this.testSuiteBean = testSuiteBean;
	}

	public Integer getTestSuiteId() {
		return testSuiteId;
	}

	public void setTestSuiteId(Integer testSuiteId) {
		this.testSuiteId = testSuiteId;
	}
	
	

}
