import axios from 'axios';

const API_URL = process.env.REACT_APP_API_SERVER_NAME + ':' + process.env.REACT_APP_API_SERVER_HOST + "/api/";

export class CategoryService {
    getTestData() {
       return  axios.get(API_URL + 'getTestData'); 
    }
    
}