import { Action } from 'redux';
import { ReportList } from '../../models/Report'
import axios from 'axios';

export interface FetchReports extends Action<'FETCH_REPORTS'> {
    reportList: any;
}

export const fetchReports = (): FetchReports => ({
    type: 'FETCH_REPORTS',
    reportList:  axios.get(process.env.REACT_APP_API_SERVER_NAME + ':' + process.env.REACT_APP_API_SERVER_HOST+ '/api/getTestSuiteNames')
});

