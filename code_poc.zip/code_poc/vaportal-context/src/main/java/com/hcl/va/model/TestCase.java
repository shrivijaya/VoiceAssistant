package com.hcl.va.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcl.va.bean.TestData;


/**
 * The persistent class for the test_case database table.
 * 
 */
@Entity
@Table(name="test_case")
@NamedQuery(name="TestCase.findAll", query="SELECT t FROM TestCase t")
public class TestCase implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name="CHILD_ID")
	private Integer childId;

	@Column(name="CREATED_ON")
	private LocalDateTime createdOn;

	@Column(name="EXPECTED_OUTPUT_TEXT")
	private String expectedOutputText;

	@Column(name="IMG_EXTRACTED_TEXT")
	private String imgExtractedText;

	@Column(name="IMG_URL")
	private String imgUrl;

	@Column(name="INPUT_AUDIO_URL")
	private String inputAudioUrl;

	@Column(name="INPUT_TEXT")
	private String inputText;

	@Column(name="IS_CONTEXTUAL")
	private Boolean isContextual;

	private String language;

	@Column(name="TEST_CASE_NAME")
	private String testCaseName;

	//bi-directional many-to-one association to RunReportDetail
	@OneToMany(mappedBy="testCase")
	private List<TestRunReport> runReportDetails;

	//bi-directional many-to-many association to TestSuite
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name = "test_suite_mapping", joinColumns = { @JoinColumn(name = "CASE_ID") }, inverseJoinColumns = {
			@JoinColumn(name = "SUIT_ID") })
	private Set<TestSuite> testSuites = new HashSet<>();
	
	@Transient
	private String base64Image;
	
	@JsonInclude
    @Transient
    private Integer parentId;
	
	@JsonInclude
    @Transient
    private TestData childData;
	
	@JsonInclude
	@Transient
	private Boolean isChecked;

	public TestCase() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getChildId() {
		return this.childId;
	}

	public void setChildId(Integer childId) {
		this.childId = childId;
	}

	public LocalDateTime getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public String getExpectedOutputText() {
		return this.expectedOutputText;
	}

	public void setExpectedOutputText(String expectedOutputText) {
		this.expectedOutputText = expectedOutputText;
	}

	public String getImgExtractedText() {
		return this.imgExtractedText;
	}

	public void setImgExtractedText(String imgExtractedText) {
		this.imgExtractedText = imgExtractedText;
	}

	public String getImgUrl() {
		return this.imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getInputAudioUrl() {
		return this.inputAudioUrl;
	}

	public void setInputAudioUrl(String inputAudioUrl) {
		this.inputAudioUrl = inputAudioUrl;
	}

	public String getInputText() {
		return this.inputText;
	}

	public void setInputText(String inputText) {
		this.inputText = inputText;
	}

	public Boolean getIsContextual() {
		return this.isContextual;
	}

	public void setIsContextual(Boolean isContextual) {
		this.isContextual = isContextual;
	}

	public String getLanguage() {
		return this.language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getTestCaseName() {
		return this.testCaseName;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public List<TestRunReport> getRunReportDetails() {
		return this.runReportDetails;
	}

	public void setRunReportDetails(List<TestRunReport> runReportDetails) {
		this.runReportDetails = runReportDetails;
	}

	public TestRunReport addRunReportDetail(TestRunReport runReportDetail) {
		getRunReportDetails().add(runReportDetail);
		runReportDetail.setTestCase(this);

		return runReportDetail;
	}

	public TestRunReport removeRunReportDetail(TestRunReport runReportDetail) {
		getRunReportDetails().remove(runReportDetail);
		runReportDetail.setTestCase(null);

		return runReportDetail;
	}

	public Set<TestSuite> getTestSuites() {
		return this.testSuites;
	}

	public void setTestSuites(Set<TestSuite> testSuites) {
		this.testSuites = testSuites;
	}

	public String getBase64Image() {
		return base64Image;
	}

	public void setBase64Image(String base64Image) {
		this.base64Image = base64Image;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public TestData getChildData() {
		return childData;
	}

	public void setChildData(TestData childData) {
		this.childData = childData;
	}

	public Boolean getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Boolean isChecked) {
		this.isChecked = isChecked;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestCase other = (TestCase) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	

}