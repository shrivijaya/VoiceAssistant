import * as React from 'react'
import { ConnectedReportForm } from '../ReportsForm'
export class Reports extends React.Component {
    render() {
        return (
            <>
                <ConnectedReportForm/>
            </>
        )
    }
}