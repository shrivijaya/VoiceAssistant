import axios from 'axios';
const API_HOST_NAME_WITH_PORT = process.env.REACT_APP_API_SERVER_NAME + ':'+ process.env.REACT_APP_API_SERVER_HOST + '/api';

export class ReportService {
  getExecutedTestSuteBySuitId(id) {
    return  axios.get(API_HOST_NAME_WITH_PORT + '/getTestSuiteRunReport?id=' + id);
  }
    getTestSuiteById(id,runId) {
       return  axios.get(API_HOST_NAME_WITH_PORT + '/getTestSuiteReport?id=' + id+"&runId="+runId);
    }

}