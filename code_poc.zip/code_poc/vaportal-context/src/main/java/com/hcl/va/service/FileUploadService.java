package com.hcl.va.service;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.PutObjectRequest;

@Service
public class FileUploadService {
	private static final Logger log = LoggerFactory.getLogger(DataProcessingService.class);

	@Value("${aws.api.secretkey}")
	private String secretKey;

	@Value("${aws.api.accesskey}")
	private String accessKey;

	@Value("${aws.s3.bucket}")
	private String bucket;

	@Value("${aws.s3.region}")
	private String region;

	public String uploadToAWS(File file) {

		log.info("uploading file to s3 file name " + file.getName());
		AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		try {
			AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.fromName(region))
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).build();

			s3Client.putObject(new PutObjectRequest(bucket, file.getName(), file)
					.withCannedAcl(CannedAccessControlList.PublicRead));
			String url = "https://s3." + region + ".amazonaws.com/" + bucket + "/" + file.getName();

			log.info("file uploaded to s3 url : " + url);
			return url;
		} catch (AmazonServiceException e) {
			throw e;
		} catch (SdkClientException e) {
			throw e;
		}

	}

}
