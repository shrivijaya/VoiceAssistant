package com.hcl.va.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the TEST_RUN_REPORT database table.
 * 
 */
@Entity
@Table(name="TEST_RUN_REPORT")
@NamedQuery(name="TestRunReport.findAll", query="SELECT r FROM TestRunReport r")
public class TestRunReport implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name="AUDIO_SCORE")
	private double audioScore;

	@Column(name="CHILD_ID")
	private int childId;

	@Column(name="COMPARISON_RESPONSE")
	private String comparisonResponse;

	@Column(name="CREATED_ON")
	private LocalDateTime createdOn;

	@Column(name="EXPECTED_OUTPUT_TEXT")
	private String expectedOutputText;

	@Column(name="IMAGE_SCORE")
	private double imageScore;

	@Column(name="INPUT_AUDIO_URL")
	private String inputAudioUrl;

	@Column(name="INPUT_IMAGE_URL")
	private String inputImageUrl;

	@Column(name="INPUT_IMG_TXT")
	private String inputImgTxt;

	@Column(name="INPUT_TEXT")
	private String inputText;

	@Column(name="RECORDED_AUDIO_TXT")
	private String recordedAudioTxt;

	@Column(name="RECORDED_AUDIO_URL")
	private String recordedAudioUrl;

	@Column(name="RECORDED_IMAGE_TXT")
	private String recordedImageTxt;

	@Column(name="RECORDED_IMAGE_URL")
	private String recordedImageUrl;

	private String result;

	private double score;

	@Column(name="TEST_CASE_NAME")
	private String testCaseName;

	//bi-directional many-to-one association to TestCase
	@ManyToOne
	@JoinColumn(name="CASE_ID")
	private TestCase testCase;

	//bi-directional many-to-one association to TestSuitRunReport
	@ManyToOne
	@JoinColumn(name="RUN_ID")
	private TestSuitRunReport testSuitRunReport;

	public TestRunReport() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public double getAudioScore() {
		return this.audioScore;
	}

	public void setAudioScore(double audioScore) {
		this.audioScore = audioScore;
	}

	public int getChildId() {
		return this.childId;
	}

	public void setChildId(int childId) {
		this.childId = childId;
	}

	public String getComparisonResponse() {
		return this.comparisonResponse;
	}

	public void setComparisonResponse(String comparisonResponse) {
		this.comparisonResponse = comparisonResponse;
	}

	public LocalDateTime getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public String getExpectedOutputText() {
		return this.expectedOutputText;
	}

	public void setExpectedOutputText(String expectedOutputText) {
		this.expectedOutputText = expectedOutputText;
	}

	public double getImageScore() {
		return this.imageScore;
	}

	public void setImageScore(double imageScore) {
		this.imageScore = imageScore;
	}

	public String getInputAudioUrl() {
		return this.inputAudioUrl;
	}

	public void setInputAudioUrl(String inputAudioUrl) {
		this.inputAudioUrl = inputAudioUrl;
	}

	public String getInputImageUrl() {
		return this.inputImageUrl;
	}

	public void setInputImageUrl(String inputImageUrl) {
		this.inputImageUrl = inputImageUrl;
	}

	public String getInputImgTxt() {
		return this.inputImgTxt;
	}

	public void setInputImgTxt(String inputImgTxt) {
		this.inputImgTxt = inputImgTxt;
	}

	public String getInputText() {
		return this.inputText;
	}

	public void setInputText(String inputText) {
		this.inputText = inputText;
	}

	public String getRecordedAudioTxt() {
		return this.recordedAudioTxt;
	}

	public void setRecordedAudioTxt(String recordedAudioTxt) {
		this.recordedAudioTxt = recordedAudioTxt;
	}

	public String getRecordedAudioUrl() {
		return this.recordedAudioUrl;
	}

	public void setRecordedAudioUrl(String recordedAudioUrl) {
		this.recordedAudioUrl = recordedAudioUrl;
	}

	public String getRecordedImageTxt() {
		return this.recordedImageTxt;
	}

	public void setRecordedImageTxt(String recordedImageTxt) {
		this.recordedImageTxt = recordedImageTxt;
	}

	public String getRecordedImageUrl() {
		return this.recordedImageUrl;
	}

	public void setRecordedImageUrl(String recordedImageUrl) {
		this.recordedImageUrl = recordedImageUrl;
	}

	public String getResult() {
		return this.result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public double getScore() {
		return this.score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public String getTestCaseName() {
		return this.testCaseName;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public TestCase getTestCase() {
		return this.testCase;
	}

	public void setTestCase(TestCase testCase) {
		this.testCase = testCase;
	}

	public TestSuitRunReport getTestSuitRunReport() {
		return this.testSuitRunReport;
	}

	public void setTestSuitRunReport(TestSuitRunReport testSuitRunReport) {
		this.testSuitRunReport = testSuitRunReport;
	}

}