import *  as React from 'react';

import { CategoryModel, languagesList } from '../../models/CategoryModel';
import { ToastContainer, toast } from 'react-toastify';
import { MediaService } from '../../services/MediaService';
import { Modal,Button } from 'react-bootstrap';
import { CategoryService } from '../../services/CategoryService';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';

import 'react-toastify/dist/ReactToastify.css';
import './index.css'
import { Z_RLE } from 'zlib';


export class CategoryForm extends React.Component<{}, CategoryModel> {
    mediaServiceObj: MediaService;
    categoryService:CategoryService;
    constructor(props) {
        super(props)
        this.handleChange = this.handleChange.bind(this);
        this.handleAddMore = this.handleAddMore.bind(this);
        this.handleResponseChange = this.handleResponseChange.bind(this);
        this.handleRemoveResponse = this.handleRemoveResponse.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
        this.handleLanguageChange = this.handleLanguageChange.bind(this);
        this.clearForm = this.clearForm.bind(this);
        this.mediaServiceObj =new MediaService(this);
        this.categoryService = new CategoryService();
    }

    state: CategoryModel = {
        text_case: "",
        command: "",
        responses: [
            { name: "" }
        ],
        image: null,
        selected: "",
        loader: false,
        fileName: "",
        enbleVideo:false,
        cimage:"",
        showModal:false,
        parentTestCases:[],
        parentLoader:true,
        selectedParent:""
    }

    handleChange = (propertyName, event) => {
        const LoginFields = this.state;
        LoginFields[propertyName] = event.target.value;
        this.setState(LoginFields)
    }

    handleFileChange = (event) => {
        this.setState({
            image: event.target.files[0],
            fileName: event.target.files[0].name
        })
    }

    handleResponseChange = (responseId, event) => {
        const newResponse = this.state.responses.map((res, index) => {
            if (responseId !== index) {
                return res;
            }

            return { ...res, name: event.target.value };
        });

        this.setState({ responses: newResponse });
    }

    handleLanguageChange(event) {
        this.setState({ selected: event.target.value })
    }
    handleParentChange(event) {
        this.setState({ selectedParent: event.target.value })
    }
    
    handleAddMore = () => {
        this.setState({
            responses: this.state.responses.concat([{ name: "" }])
        });
    };

    handleRemoveResponse = (idx) => {
        this.setState({
            responses: this.state.responses.filter((s, sidx) => (idx !== sidx))
        });
    };

    notifyMessage = (message, statusCode) => {
        switch (statusCode) {
            case 200:
                toast.info(message, {
                    position: toast.POSITION.TOP_RIGHT
                });
                break;

            default:
                toast.error(message, {
                    position: toast.POSITION.TOP_LEFT
                });
        }
    }
    captureImage = async () => {
        // console.log(this)
        this.setState({ enbleVideo: true });
        let imageData:any = await this.mediaServiceObj.getVideoSnapshot(this);
        this.setState({ cimage: imageData.imageData });
    }
    submitForm = (event) => {
        event.preventDefault();
        if(this.state.cimage == ""){
            this.notifyMessage("Image not captured", 500);
            return;
        }
        this.setState({ loader: true })
        let expectedOutput: any = [];

        for (let name of this.state.responses) {
            expectedOutput.push(name.name)
        }

        let formData = new FormData();

        formData.append('testData', JSON.stringify({
            "testCaseName": this.state.text_case,
            "inputText": this.state.command,
            "base64Image": this.state.cimage,
            "expectedOutput": expectedOutput.join("|"),
            "language": this.state.selected,

        }));
        let formData1 = {
                "testCaseName": this.state.text_case,
                "inputText": this.state.command,
                "base64Image": this.state.cimage,
                "expectedOutput": expectedOutput.join("|"),
                "language": this.state.selected,
                "parentId" :this.state.selectedParent,
                "isContextual":this.state.selectedParent?true:false  
        };
        

        //formData.append('file', this.state.image);

        axios.post(process.env.REACT_APP_API_SERVER_NAME + ':' + process.env.REACT_APP_API_SERVER_HOST + '/api/uploadData', formData1, {
            headers: {
                'Content-Type': 'application/json',
            }
        })
            .then((response) => {
                if (response.status === 200) {
                    this.notifyMessage(response.data.responseMessage, response.status);
                }
                this.clearForm();
                this.getTestData();
                this.setState({ loader: false });
            })
            .catch((error) => {
                this.notifyMessage("internal server error ", 500)
                this.setState({ loader: false })
            })
    }

    clearForm() {
        this.setState({
            text_case: "",
            command: "",
            image: null,
            cimage: "",
            selected: "",
            responses: [{ name: "" }],
            fileName: "",
            selectedParent:""
        });
    }

    handleClose = () => this.setState({ showModal: false });
    handleShow = () => this.setState({ showModal: true })
    getTestData = () =>{
        this.categoryService.getTestData()
        .then((resolve:any) =>{
            this.setState({parentTestCases:resolve.data.filter(el=>el.childId==null)});            
        })
        .catch(e=>{console.log(e)})
        .finally(()=>{
            this.setState({parentLoader:false});
        });
    }
    componentDidMount() {
        this.getTestData();
     }
    render() {

        const optionElements = languagesList.languages.map((lang) => {
            return (
                <option value={lang.name} key={lang.id} disabled={lang.isEnabled} className={lang.isEnabled?'' :'bolden'}>
                    {lang.text}
                </option>
            )
        });

        const parentOptionElements = this.state.parentTestCases.map((tc) => {
            return (
                <option value={tc.id} key={tc.id}>
                    {tc.testCaseName}
                </option>
            )
        });
        
        let VideoEl = <video width={400} height={300} ref="video" />
        let CanvasEl = <canvas ref="canvas" width={0} height={0} />
        return (

            <>
                <div className="form-div">
                   <b>Create Test Case</b> <br/><br/>
                    <ToastContainer />
                    <div className="row">
                        <div className="col-md-12">
                            <form onSubmit={this.submitForm} method="post">
                                <div className="row">
                                    <label>Test Case Name</label> <span className="required-filed"></span>
                                </div>
                                <div className="row">
                                    <div className="form-group col-md-8">
                                    
                                    <input type="text" className="form-control" placeholder="Enter Test Case Name" value={this.state.text_case} onChange={this.handleChange.bind(this, 'text_case')} required /> </div>
                                        <div className="form-group col-md-4">
                                            <select name="parentTestCase" value={this.state.selectedParent} onChange={this.handleParentChange.bind(this)} className="form-control" >
                                                <option value="" >{this.state.parentLoader ? 'Loading.........' : 'Select Parent (Contextual )' }</option>
                                                {parentOptionElements}
                                            </select>
                                        </div>          
                                </div>
                                
                                <div className="row">
                                    <label>Command</label> <span className="required-filed"></span>
                                </div>

                                <div className="row">
                                    <div className="form-group col-md-8">  
                                     
                                        <input type="text" className="form-control" placeholder="Ask Something" value={this.state.command} onChange={this.handleChange.bind(this, 'command')} required />
                                    </div>
                                    <div className="form-group col-md-4">
                                        <select name="language" value={this.state.selected} onChange={this.handleLanguageChange.bind(this)} className="form-control required-filed " required aria-required="true">
                                            <option value="" >Select Language</option>
                                            {optionElements}
                                        </select>
                                    </div>
                                </div>
                                <div className="row">
                                    <label>Expected Response</label> <span className="required-filed"></span>
                                </div>
                                {this.state.responses.map((response, idx) => (
                                    <div className="row" key={idx}>

                                        <div className="form-group col-md-6">
                                        
                                            <input type="text"
                                                required
                                                className="form-control"
                                                placeholder={`Utterance #${idx + 1}`}
                                                value={response.name}
                                                onChange={this.handleResponseChange.bind(this, idx)}
                                            />
                                        </div>

                                        <div className="form-group col-md-2">
                                            {
                                                (idx === 0)
                                                    ?
                                                    <button type="button" onClick={this.handleAddMore} className="btn btn-info add-more"> + </button>
                                                    :
                                                    <button type="button" onClick={this.handleRemoveResponse.bind(this, idx)} className="btn btn-info add-more"> - </button>
                                            }
                                        </div>
                                    </div>
                                ))}

                                <div className="row">
                                    <div className="form-group col-md-9 text-center">
                                        <div className="snapshot">
                                            {VideoEl}
                                            {CanvasEl}
                                        </div>
                                        {this.state.cimage!="" &&
                                        <span>
                                        <button type="button" className="btn btn-info button-view-image" onClick={this.handleShow}><FontAwesomeIcon icon="eye"/><br/> Image</button    >
                                        <Modal show={this.state.showModal} onHide={this.handleClose}>
                                            <Modal.Header closeButton>
                                            </Modal.Header>
                                            <Modal.Body><img src={this.state.cimage}></img></Modal.Body>
                                        </Modal>
                                        </span>
                                        }
                                        <button  type="button" onClick={this.captureImage} className="btn btn-info capture-image">
                                        <i className="fa fa-camera"></i><br/>
                                            Capture Image
                                            {this.state.enbleVideo &&
                                            <div className="spinner-border text-primary" role="status">
                                                <span className="sr-only">Loading...</span>
                                            </div>
                                            }
                                        </button>
                                    </div>
                                </div>
                                
                                <div className="row">
                                    <div className="form-group col-md-9 text-center buttons-div">
                                        {
                                            this.state.loader
                                                ? <div className="loader">Loading...</div>
                                                :
                                                <>
                                                    <button type="submit" className="btn btn-info button-save">SAVE</button>
                                                    <button type="reset" onClick={this.clearForm} className="btn btn-outline-info button-cancel">RESET</button>
                                                </>

                                        }


                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}