module.exports = {
    setupFilesAfterEnv: ['jest-allure/dist/setup']
  };