import React, { useState } from 'react';
import ItemsCarousel from 'react-items-carousel';
import { ButtonCircle } from '../Element/ButtonCircle';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
export const DateCarousel = (props) => {
  const [activeItemIndex, setActiveItemIndex] = useState(0);
  const chevronWidth = 100;
  const style = { height: 30, background: '#EEE' };
  const itmes = props.runReports;

  return (
    <div style={{ padding: `0 ${chevronWidth}px` }}>
      <ItemsCarousel
        requestToChangeActive={setActiveItemIndex}
        activeItemIndex={activeItemIndex}
        numberOfCards={4}
        alwaysShowChevrons={true}
        gutter={20}
        outsideChevron
        chevronWidth={chevronWidth}
        rightChevron={<ButtonCircle icon="angle-right" disabled={true} />}
        leftChevron={<ButtonCircle icon="angle-left" disabled={activeItemIndex<1} />} 
      >
        {itmes.map((object,index) => <div style={style} key={index} data-id={object.id} onClick={props.handleDateOnClick}>{object.createdOn}</div>)}
      </ItemsCarousel>
    </div>
  );
};