import React from 'react';
import { render } from '@testing-library/react';
import {Navigation} from './index';
import { MemoryRouter as Router } from "react-router-dom";
import { debug } from 'console';

describe('Navigation Suite', () => {
    test('Navigation Create Test Link', () => {
        const {container,getByText,debug } = render(<Router><Navigation /></Router>);
        const linkElement = getByText(/Create Test/i);
        expect(linkElement.closest('a')).toHaveAttribute('href', '/');
    });
    test('Navigation Execute Link', () => {
        const {container,getByText,debug } = render(<Router><Navigation /></Router>);
        const linkElement = getByText(/Execute/i);
        expect(linkElement.closest('a')).toHaveAttribute('href', '/execution');
    });
    test('Navigation Report Link', () => {
        const {container,getByText,debug } = render(<Router><Navigation /></Router>);
        const linkElement = getByText(/Report/i);
        expect(linkElement.closest('a')).toHaveAttribute('href', '/reports');
    });
})